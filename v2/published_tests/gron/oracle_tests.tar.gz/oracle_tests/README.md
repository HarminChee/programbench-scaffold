# Generated CLI Oracle Tests

Instance: `tomnomnom__gron.88a6234`
Profile: `programbench_oracle_gym_v2_expansive`
Cases: `640`

These tests were generated from cleanroom-visible behavior: the ProgramBench
reference executable was copied from the cleanroom image, then profile-provided
CLI cases were executed against it to capture exact stdout, stderr, and exit
codes. The bundle does not include ProgramBench official test blobs or upstream
source code.

Run with a workspace-level `./executable`:

```bash
python3 -m pytest -q eval/tests
```
