# Generated CLI Oracle Tests

Instance: `alecthomas__chroma.8d04def`
Profile: `programbench_oracle_gym_v2_expansive`
Cases: `674`

These tests were generated from cleanroom-visible behavior: the ProgramBench
reference executable was copied from the cleanroom image, then profile-provided
CLI cases were executed against it to capture exact stdout, stderr, and exit
codes. The bundle does not include ProgramBench official test blobs or upstream
source code.

Run with a workspace-level `./executable`:

```bash
python3 -m pytest -q eval/tests
```
