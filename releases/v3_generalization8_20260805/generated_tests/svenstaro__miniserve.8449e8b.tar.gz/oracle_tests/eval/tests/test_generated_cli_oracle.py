"""Generated black-box CLI oracle tests."""

from __future__ import annotations

import contextlib
import base64
import http.server
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _programbench_lifecycle_runtime import run_lifecycle_case, run_sequence_case

WORKSPACE = Path(__file__).resolve().parents[2]
EVAL_DIR = Path(__file__).resolve().parents[1]
MANIFEST_PATH = EVAL_DIR / "generated_cli_manifest.json"
if not MANIFEST_PATH.exists():
    MANIFEST_PATH = EVAL_DIR / "generated_yj_manifest.json"
MANIFEST = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
FIXTURE_DIR = EVAL_DIR / "fixtures" / MANIFEST.get("fixture_subdir", "generated_cli")
CASES = MANIFEST["cases"]


@contextlib.contextmanager
def _case_runtime(case: dict, tmp_path: Path):
    for relative, content in case.get("files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    for relative, content in case.get("executable_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe executable fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        target.chmod(0o755)
    for relative, content in case.get("binary_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe binary fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(base64.b64decode(content, validate=True))
    for relative, spec in case.get("repeat_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe repeated fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        segments = spec.get("segments")
        content = (
            "".join(segment.get("row", "") * int(segment.get("count", 0)) for segment in segments)
            if isinstance(segments, list)
            else spec.get("prefix", "") + spec.get("row", "") * int(spec.get("count", 0)) + spec.get("suffix", "")
        )
        encoding = str(spec.get("encoding") or "utf-8").lower()
        if encoding in {"latin-1", "latin1"}:
            target.write_bytes(content.encode("latin-1"))
        else:
            target.write_text(content, encoding="utf-8")
    git_fixture = case.get("git") or None
    if git_fixture and git_fixture.get("init") is True:
        git_env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "ProgramBench",
            "GIT_AUTHOR_EMAIL": "programbench@example.invalid",
            "GIT_COMMITTER_NAME": "ProgramBench",
            "GIT_COMMITTER_EMAIL": "programbench@example.invalid",
            "GIT_AUTHOR_DATE": "2000-01-01T00:00:00Z",
            "GIT_COMMITTER_DATE": "2000-01-01T00:00:00Z",
        }
        subprocess.run(["git", "init", "-q", "-b", git_fixture.get("branch", "main")], cwd=tmp_path, env=git_env, check=True)
        if git_fixture.get("commit_all") is not False:
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
            subprocess.run(["git", "commit", "-q", "--allow-empty", "-m", "initial"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("staged_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        if git_fixture.get("staged_files"):
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("untracked_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    for relative, mode in case.get("file_modes", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents or not target.exists():
            raise AssertionError(f"invalid file mode fixture path: {relative}")
        target.chmod(int(mode) & 0o777)
    response = case.get("http") or None
    server = None
    thread = None
    url = ""
    if response:
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path != response.get("path", "/"):
                    self.send_error(404)
                    return
                body = response.get("body", "").encode("utf-8")
                self.send_response_only(response.get("status", 200))
                for key, value in response.get("headers", {}).items():
                    self.send_header(key, value)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)

            do_POST = do_GET
            do_PUT = do_GET
            do_PATCH = do_GET
            do_DELETE = do_GET
            do_OPTIONS = do_GET
            do_HEAD = do_GET

            def log_message(self, format, *args):
                return

            def date_time_string(self, timestamp=None):
                return "Thu, 01 Jan 1970 00:00:00 GMT"

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_port}{response.get('path', '/')}"
    try:
        yield url
    finally:
        if server:
            server.shutdown()
            server.server_close()
        if thread:
            thread.join(timeout=2)


def _case_timeout(case: dict) -> float:
    timeout = float(case.get("timeout", 5))
    cap = os.environ.get("PROGRAMBENCH_CASE_TIMEOUT_CAP", "").strip()
    if cap:
        timeout = min(timeout, max(0.1, float(cap)))
    return timeout


def _execute_case(index: int, tmp_path: Path) -> tuple[dict, Path, int, bytes, bytes, bytes, bytes, list, list]:
    case = CASES[index]
    executable = WORKSPACE / "executable"
    if not executable.exists():
        raise AssertionError(f"missing executable at {executable}")

    stdin_template = (FIXTURE_DIR / case["stdin_file"]).read_bytes()
    expected_stdout = (FIXTURE_DIR / case["stdout_file"]).read_bytes()
    expected_stderr = (FIXTURE_DIR / case["stderr_file"]).read_bytes()
    env = os.environ.copy()
    env["TZ"] = "UTC"
    with _case_runtime(case, tmp_path) as http_url:
        if case.get("isolate_home_tmp") is True:
            isolated_home = tmp_path / ".case-home"
            isolated_tmp = tmp_path / ".case-tmp"
            isolated_home.mkdir(exist_ok=True)
            isolated_tmp.mkdir(exist_ok=True)
            env.update({"HOME": str(isolated_home), "TMPDIR": str(isolated_tmp)})
        env.update({key: value.replace("{http_url}", http_url) for key, value in case.get("env", {}).items()})
        argv0 = case.get("argv0", "/workspace/executable").replace("{http_url}", http_url)
        args = [item.replace("{http_url}", http_url) for item in case["args"]]
        stdin = stdin_template.replace(b"{http_url}", http_url.encode("utf-8"))
        interactions = []
        if case.get("sequence"):
            sequence = json.loads(
                json.dumps(case["sequence"])
                .replace("{http_url}", http_url)
                .replace("{http_host}", http_url.split("://", 1)[-1] if http_url else "")
            )
            observed = run_sequence_case(
                executable=executable, argv0=argv0, sequence=sequence,
                cwd=tmp_path, env=env, timeout=_case_timeout(case),
            )
            returncode, stdout, stderr = observed["returncode"], observed["stdout"], observed["stderr"]
            interactions = observed.get("interactions") or []
        elif case.get("lifecycle"):
            observed = run_lifecycle_case(
                executable=executable, argv0=argv0, args=args, stdin=stdin,
                cwd=tmp_path, env=env, timeout=_case_timeout(case),
                lifecycle=case["lifecycle"],
            )
            returncode, stdout, stderr = observed["returncode"], observed["stdout"], observed["stderr"]
            interactions = observed.get("interactions") or []
        elif case.get("terminal"):
            returncode, stdout, stderr = _run_terminal(
                executable=executable,
                argv0=argv0,
                args=args,
                stdin=stdin,
                cwd=tmp_path,
                env=env,
                timeout=_case_timeout(case),
                terminal=case["terminal"],
            )
        else:
            stdin_file = None
            if case.get("stdin_regular_file") is True:
                stdin_path = tmp_path / ".programbench-stdin"
                stdin_path.write_bytes(stdin)
                stdin_file = stdin_path.open("rb")
            proc = subprocess.Popen(
                [argv0, *args],
                executable=str(executable),
                stdin=stdin_file if stdin_file is not None else subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=tmp_path,
                env=env,
                start_new_session=os.name != "nt",
            )
            try:
                stdout, stderr = proc.communicate(
                    input=None if stdin_file is not None else stdin,
                    timeout=_case_timeout(case),
                )
                if stdin_file is not None:
                    stdin_file.close()
            except subprocess.TimeoutExpired:
                if stdin_file is not None:
                    stdin_file.close()
                if os.name != "nt":
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
                proc.communicate()
                raise
            returncode = proc.returncode
        if http_url:
            encoded_url = http_url.encode("utf-8")
            encoded_host = http_url.split("://", 1)[-1].split("/", 1)[0].encode("utf-8")
            stdout = stdout.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")
            stderr = stderr.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")
        encoded_workdir = str(tmp_path).encode("utf-8")
        stdout = stdout.replace(encoded_workdir, b"{workdir}")
        stderr = stderr.replace(encoded_workdir, b"{workdir}")

    expected_interactions = case.get("interactions") or []
    return case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions


def _run_terminal(*, executable: Path, argv0: str, args: list[str], stdin: bytes, cwd: Path,
                  env: dict[str, str], timeout: int, terminal: dict) -> tuple[int, bytes, bytes]:
    if os.name == "nt":
        raise RuntimeError("terminal cases require a Unix pseudo-terminal")
    import fcntl
    import pty
    import select
    import struct
    import termios

    kind = str(terminal.get("kind") or "generic")
    if kind not in {"generic", "iterm2", "kitty", "sixel"}:
        raise ValueError("terminal.kind must be generic, iterm2, kitty, or sixel")
    rows = max(2, min(200, int(terminal.get("rows", 24))))
    cols = max(2, min(400, int(terminal.get("cols", 80))))
    cell_width = max(1, min(100, int(terminal.get("cell_width", 10))))
    cell_height = max(1, min(100, int(terminal.get("cell_height", 20))))
    max_output = max(1024, min(16 * 1024 * 1024, int(terminal.get("max_output_bytes", 4 * 1024 * 1024))))
    stdin_delay = max(0.0, min(5.0, float(terminal.get("stdin_delay_seconds", 0))))
    stdin_mode = "pipe" if terminal.get("stdin_mode") == "pipe" else "pty"
    run_env = dict(env)
    run_env.update({
        "TERM_PROGRAM": "iTerm.app" if kind == "iterm2" else "ProgramBench",
        "TERM": str(terminal.get("term") or "xterm-256color"),
    })
    master, slave = pty.openpty()
    attrs = termios.tcgetattr(slave)
    attrs[3] &= ~termios.ECHO
    termios.tcsetattr(slave, termios.TCSANOW, attrs)
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    proc = subprocess.Popen(
        [argv0, *args], executable=str(executable),
        stdin=subprocess.PIPE if stdin_mode == "pipe" else slave, stdout=slave, stderr=slave,
        cwd=cwd, env=run_env, start_new_session=True, close_fds=True,
    )
    os.close(slave)
    def feed_stdin() -> None:
        if stdin_delay:
            time.sleep(stdin_delay)
        with contextlib.suppress(BrokenPipeError, OSError):
            if stdin_mode == "pipe":
                if proc.stdin is not None:
                    if stdin:
                        proc.stdin.write(stdin)
                    for event in terminal.get("input_events") or []:
                        delay = max(0.0, min(5.0, float(event.get("after_seconds", 0))))
                        if delay:
                            time.sleep(delay)
                        proc.stdin.write(str(event.get("data") or "").encode("utf-8"))
                    proc.stdin.close()
            else:
                if stdin:
                    os.write(master, stdin)
                for event in terminal.get("input_events") or []:
                    delay = max(0.0, min(5.0, float(event.get("after_seconds", 0))))
                    if delay:
                        time.sleep(delay)
                    os.write(master, str(event.get("data") or "").encode("utf-8"))
                if terminal.get("send_eof") is True:
                    os.write(master, b"\x04")
    feeder = threading.Thread(target=feed_stdin, daemon=True)
    feeder.start()
    output = bytearray()
    responses = {b"\x1b[14t": f"\x1b[4;{rows * cell_height};{cols * cell_width}t".encode("ascii")}
    if kind == "iterm2":
        responses[b"\x1b]1337;ReportCellSize\x07"] = f"\x1b]1337;ReportCellSize={cell_height};{cell_width}\x1b\\".encode("ascii")
    if kind == "kitty":
        responses[b"\x1b_Gi=1,a=q,t=d,f=24\x1b\\"] = b"\x1b_Gi=1;OK\x1b\\"
    if kind == "sixel":
        responses[b"\x1b[c"] = b"\x1b[?62;4;c"
    responded: set[bytes] = set()
    deadline = time.monotonic() + timeout
    try:
        while proc.poll() is None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=5)
                raise subprocess.TimeoutExpired([argv0, *args], timeout, output=bytes(output))
            ready, _, _ = select.select([master], [], [], min(0.1, remaining))
            if not ready:
                continue
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            output.extend(chunk)
            if len(output) > max_output:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                raise RuntimeError("terminal case exceeded max_output_bytes")
            for query, response in responses.items():
                if query not in responded and query in output:
                    os.write(master, response)
                    responded.add(query)
        proc.wait(timeout=5)
        while True:
            ready, _, _ = select.select([master], [], [], 0.02)
            if not ready:
                break
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            if not chunk:
                break
            output.extend(chunk)
    finally:
        feeder.join(timeout=6)
        os.close(master)
    return proc.returncode, bytes(output), b""


GO_LOG_PREFIX_RE = re.compile(
    rb"(?m)^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [^ \r\n]+\.go:\d+:)? "
)
BENCH_DURATION_RE = re.compile(
    rb"(?m)^(\s*(?:Total|Slowest|Fastest|Average):\s*)[0-9.]+(\s+secs\.)$"
)
BENCH_RATE_RE = re.compile(rb"(?m)^(\s*Requests/sec:\s*)[0-9.]+$")
BENCH_HISTOGRAM_RE = re.compile(rb"(?m)^(\s*)[0-9.]+(\s+\[\d+\]\s*\|.*)$")
BENCH_LATENCY_RE = re.compile(rb"(?m)^(\s*\d+% in\s*)[0-9.]+(\s+secs\.)$")
SEVENZIP_BENCH_NUMBER_RE = re.compile(rb"(?<![A-Za-z])[+-]?\d+(?:\.\d+)?(?:[A-Za-z/%]+)?")


EPOCH_NUMBER_RE = re.compile(rb"(?<!\d)[1-3]\d{9}(?!\d)")
ANSI_ESCAPE_RE = re.compile(rb"\x1b(?:\[[0-?]*[ -/]*[@-~]|.)", re.DOTALL)
NINJA_GRAPHVIZ_ID_RE = re.compile(rb"\b0x[0-9a-fA-F]+\b")
NINJA_COMPDB_DIRECTORY_RE = re.compile(rb'("directory"\s*:\s*")[^"]*(")')
NINJA_STATS_NUMBER_RE = re.compile(rb"(?<![A-Za-z])\d+(?:\.\d+)?")


def _normalize_ninja_graphviz_ids(value: bytes) -> bytes:
    return NINJA_GRAPHVIZ_ID_RE.sub(b"0xNODE", value)


def _normalize_ninja_compdb_directory(value: bytes) -> bytes:
    return NINJA_COMPDB_DIRECTORY_RE.sub(rb'\g<1><WORKDIR>\g<2>', value)


def _normalize_ninja_stats(value: bytes) -> bytes:
    return NINJA_STATS_NUMBER_RE.sub(b"<N>", value)


def _normalize_terminal_control_tail(value: bytes) -> bytes:
    cursor = 0
    last_visible_end = 0
    for match in ANSI_ESCAPE_RE.finditer(value):
        chunk = value[cursor:match.start()]
        if chunk.strip():
            last_visible_end = match.start()
        cursor = match.end()
    if value[cursor:].strip():
        last_visible_end = len(value)
    if not last_visible_end or last_visible_end == len(value):
        return value
    return value[:last_visible_end] + b"\n<TERMINAL_CONTROL_TAIL>\n"


def _normalize_benchmark_output(value: bytes) -> bytes:
    value = BENCH_DURATION_RE.sub(rb"\g<1>0.0000\g<2>", value)
    value = BENCH_RATE_RE.sub(rb"\g<1>0.0000", value)
    value = BENCH_HISTOGRAM_RE.sub(rb"\g<1>0.000\g<2>", value)
    value = BENCH_LATENCY_RE.sub(rb"\g<1>0.0000\g<2>", value)
    if b"Compressing  |" not in value:
        return value
    lines = value.splitlines(keepends=True)
    table_index = next(i for i, line in enumerate(lines) if b"Compressing  |" in line)
    system_index = next(
        (
            i
            for i, line in enumerate(lines[:table_index])
            if line.strip().startswith((b"Compiler:", b"Linux :", b"PageSize:"))
        ),
        table_index,
    )
    lines = lines[:system_index] + [b"<SYSTEM>\n", b"\n"] + lines[table_index:]
    normalized = []
    in_table = False
    for line in lines:
        if b"Compressing  |" in line:
            in_table = True
        if in_table and any(48 <= byte <= 57 for byte in line):
            line = SEVENZIP_BENCH_NUMBER_RE.sub(b"<N>", line)
            line = b" ".join(line.split()) + b"\n"
        normalized.append(line)
    return b"".join(normalized)


TUI_WPM_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=WPM\b)")
TUI_ACC_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=% Acc\b)")


def _normalize_tui_metrics(value: bytes) -> bytes:
    value = TUI_WPM_METRIC_RE.sub(rb"\g<1><WPM>", value)
    return TUI_ACC_METRIC_RE.sub(rb"\g<1><ACC>", value)


def _assert_stdout(case: dict, stdout: bytes, expected_stdout: bytes) -> None:
    if case.get("stdout_mode") == "lines_unordered":
        assert sorted(stdout.splitlines()) == sorted(expected_stdout.splitlines())
    else:
        assert stdout == expected_stdout


def _assert_observed_files(case: dict, tmp_path: Path) -> None:
    root = tmp_path.resolve()
    for relative, expected in case.get("observed_files", {}).items():
        target = tmp_path / relative
        exists = target.exists() or target.is_symlink()
        assert exists is bool(expected.get("exists")), f"post-run existence mismatch: {relative}"
        if not exists:
            continue
        resolved = target.resolve()
        assert resolved == root or root in resolved.parents, f"post-run path escaped workspace: {relative}"
        kind = expected.get("kind")
        if kind == "directory":
            assert target.is_dir(), f"expected post-run directory: {relative}"
        elif kind == "file":
            assert target.is_file(), f"expected post-run file: {relative}"
            expected_bytes = base64.b64decode(expected.get("content_base64", ""), validate=True)
            assert target.read_bytes() == expected_bytes, f"post-run bytes mismatch: {relative}"


def _normalize_terminal_final_screen(value: bytes, *, rows: int, cols: int) -> bytes:
    """Reconstruct the final visible ANSI terminal screen for exact comparison."""

    rows = max(2, min(200, int(rows)))
    cols = max(2, min(400, int(cols)))
    screen = [[" "] * cols for _ in range(rows)]
    row = col = 0
    saved = (0, 0)
    last_screen: list[list[str]] | None = None
    text = value.decode("utf-8", "replace")

    def clear_all() -> None:
        nonlocal screen
        screen = [[" "] * cols for _ in range(rows)]

    def snapshot() -> None:
        nonlocal last_screen
        last_screen = [line[:] for line in screen]

    index = 0
    while index < len(text):
        char = text[index]
        if char == "\x1b":
            if index + 1 < len(text) and text[index + 1] == "[":
                match = re.match(r"\x1b\[([0-?]*)([ -/]*)([@-~])", text[index:])
                if match:
                    params, _, command = match.groups()
                    index += len(match.group(0))
                    private = params.startswith("?")
                    raw_params = params[1:] if private else params
                    numbers = [int(item) if item else 0 for item in raw_params.split(";")] if raw_params else []
                    first = numbers[0] if numbers else 0
                    if private and first == 1049 and command == "h":
                        clear_all()
                        row = col = 0
                    elif private and first == 1049 and command == "l":
                        snapshot()
                    elif command in {"H", "f"}:
                        row = max(0, min(rows - 1, (numbers[0] if numbers else 1) - 1))
                        col = max(0, min(cols - 1, (numbers[1] if len(numbers) > 1 else 1) - 1))
                    elif command == "A":
                        row = max(0, row - (first or 1))
                    elif command == "B":
                        row = min(rows - 1, row + (first or 1))
                    elif command == "C":
                        col = min(cols - 1, col + (first or 1))
                    elif command == "D":
                        col = max(0, col - (first or 1))
                    elif command == "E":
                        row, col = min(rows - 1, row + (first or 1)), 0
                    elif command == "F":
                        row, col = max(0, row - (first or 1)), 0
                    elif command in {"G", "`"}:
                        col = max(0, min(cols - 1, (first or 1) - 1))
                    elif command == "d":
                        row = max(0, min(rows - 1, (first or 1) - 1))
                    elif command == "J":
                        if first in {2, 3}:
                            clear_all()
                        elif first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                            for target in range(row + 1, rows):
                                screen[target] = [" "] * cols
                        elif first == 1:
                            for target in range(row):
                                screen[target] = [" "] * cols
                            screen[row][: col + 1] = [" "] * (col + 1)
                    elif command == "K":
                        if first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                        elif first == 1:
                            screen[row][: col + 1] = [" "] * (col + 1)
                        elif first == 2:
                            screen[row] = [" "] * cols
                    elif command == "s":
                        saved = (row, col)
                    elif command == "u":
                        row, col = saved
                    continue
            if index + 1 < len(text) and text[index + 1] in {"7", "8"}:
                if text[index + 1] == "7":
                    saved = (row, col)
                else:
                    row, col = saved
                index += 2
                continue
            if index + 1 < len(text) and text[index + 1] == "]":
                end_bel = text.find("\x07", index + 2)
                end_st = text.find("\x1b\\", index + 2)
                endings = [item for item in (end_bel, end_st) if item >= 0]
                index = (min(endings) + (2 if min(endings) == end_st else 1)) if endings else len(text)
                continue
            index += 2
            continue
        if char == "\r":
            col = 0
        elif char == "\n":
            row = min(rows - 1, row + 1)
        elif char == "\b":
            col = max(0, col - 1)
        elif char >= " " and char != "\x7f":
            screen[row][col] = char
            col += 1
            if col >= cols:
                col = 0
                row = min(rows - 1, row + 1)
        index += 1

    selected = last_screen or screen
    lines = ["".join(line).rstrip() for line in selected]
    while lines and not lines[-1]:
        lines.pop()
    return ("<TERMINAL_FINAL_SCREEN>\n" + "\n".join(lines) + "\n").encode("utf-8")


def test_0000_batch_initial_001_0000_help_flag_output(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(0, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0001_batch_initial_001_0001_version_flag_output(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(1, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0002_batch_initial_001_0002_print_manpage(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(2, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0003_batch_initial_001_0003_print_completions_bash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(3, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0004_batch_initial_001_0004_print_completions_zsh(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(4, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0005_batch_initial_001_0005_print_completions_invalid_shell(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(5, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0006_batch_initial_001_0012_route_prefix_and_random_conflict_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(6, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0007_batch_initial_001_0014_spa_without_index_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(7, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0008_batch_initial_001_0017_auth_invalid_hash_method_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(8, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0009_batch_initial_001_0018_auth_invalid_format_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(9, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0010_batch_initial_001_0020_auth_file_missing_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(10, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0011_batch_initial_001_0023_chmod_requires_upload_dir_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(11, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0012_batch_initial_001_0025_mkdir_requires_upload_dir_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(12, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0013_batch_initial_001_0026_tls_cert_without_key_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(13, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0014_batch_initial_001_0032_invalid_sorting_method_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(14, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0015_batch_initial_001_0034_color_scheme_invalid_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(15, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0016_batch_initial_001_0059_interface_bind_invalid_ip_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(16, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0017_batch_initial_001_0068_on_duplicate_files_invalid_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(17, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0018_batch_initial_001_0071_temp_directory_requires_upload(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(18, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0019_batch_initial_001_0073_temp_directory_nonexistent_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(19, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0020_batch_initial_002_0011_route_prefix_conflicts_random_route_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(20, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0021_batch_initial_002_0012_spa_requires_index_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(21, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0022_batch_initial_002_0014_auth_invalid_format_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(22, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0023_batch_initial_002_0015_auth_password_too_long_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(23, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0024_batch_initial_002_0016_auth_sha256_hash_invalid_hex_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(24, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0025_batch_initial_002_0017_auth_unknown_hash_method_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(25, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0026_batch_initial_002_0019_header_malformed_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(26, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0027_batch_initial_002_0020_mkdir_requires_upload_files_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(27, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0028_batch_initial_002_0021_media_type_requires_upload_dir_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(28, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0029_batch_initial_002_0022_raw_media_type_conflicts_media_type_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(29, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0030_batch_initial_002_0023_chmod_requires_upload_dir_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(30, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0031_batch_initial_002_0024_temp_directory_requires_upload_dir_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(31, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0032_batch_initial_002_0025_tls_cert_requires_key_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(32, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0033_batch_initial_002_0058_web_upload_concurrency_set(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(33, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0034_batch_initial_002_0059_on_duplicate_files_rename(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(34, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0035_batch_initial_002_0060_on_duplicate_files_overwrite(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(35, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0036_batch_initial_002_0074_upload_with_media_type_image(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(36, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0037_batch_initial_002_0075_upload_with_raw_media_type(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(37, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0038_batch_initial_004_0004_lp_print_completions_fish(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(38, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0039_batch_initial_004_0011_lp_spa_requires_index(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(39, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0040_batch_initial_004_0013_lp_route_prefix_and_random_conflict(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(40, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0041_batch_initial_004_0017_lp_auth_invalid_format_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(41, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0042_batch_initial_004_0018_lp_auth_invalid_hash_method_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(42, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0043_batch_initial_004_0024_lp_media_type_requires_upload(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(43, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0044_batch_initial_004_0026_lp_raw_media_type_conflicts(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(44, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0045_batch_initial_004_0042_lp_header_malformed_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(45, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0046_batch_initial_005_0023_upload_duplicate_file_conflict(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(46, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0047_batch_initial_005_0024_upload_duplicate_rename_success(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(47, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0048_batch_initial_005_0035_chmod_uploaded_file_permission_state(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(48, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0049_batch_initial_005_0050_cli_help_output_pipe(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(49, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0050_batch_initial_005_0051_cli_print_completions_bash_stream(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(50, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0051_batch_initial_005_0052_cli_print_completions_invalid_shell_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(51, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0052_batch_initial_005_0053_print_manpage_stream(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(52, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0053_batch_initial_005_0054_symlink_traversal_upload_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(53, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0054_batch_initial_005_0056_upload_concurrency_config_state(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(54, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0055_batch_initial_006_0010_random_route_conflicts_with_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(55, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0056_batch_initial_006_0011_spa_requires_index(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(56, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0057_batch_initial_006_0012_mkdir_requires_upload_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(57, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0058_batch_initial_006_0013_chmod_requires_upload_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(58, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0059_batch_initial_006_0014_header_malformed_missing_colon(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(59, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0060_batch_initial_006_0016_auth_malformed_no_colon(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(60, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0061_batch_initial_006_0017_auth_invalid_hash_method(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(61, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0062_batch_initial_006_0018_auth_invalid_password_hash_hex(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(62, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0063_batch_initial_006_0020_invalid_interface_address(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(63, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0064_batch_initial_006_0023_invalid_size_display_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(64, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0065_batch_initial_006_0025_invalid_default_sorting_method(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(65, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0066_batch_initial_006_0027_color_scheme_invalid_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(66, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0067_batch_initial_006_0029_on_duplicate_files_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(67, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0068_batch_initial_006_0031_tls_cert_without_key_fails(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(68, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0069_batch_initial_006_0032_tls_key_without_cert_fails(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(69, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0070_batch_initial_006_0067_temp_directory_requires_upload_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(70, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0071_batch_initial_006_0069_temp_directory_nonexistent_fails(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(71, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0072_batch_initial_006_0076_auth_file_missing_path_fails(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(72, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0073_batch_initial_006_0078_raw_media_type_conflicts_with_media_type(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(73, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0074_batch_initial_007_0012_route_prefix_conflicts_random(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(74, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0075_batch_initial_007_0017_spa_requires_index(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(75, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0076_batch_initial_007_0023_auth_invalid_format_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(76, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0077_batch_initial_007_0024_auth_unknown_hash_method(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(77, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0078_batch_initial_007_0036_mkdir_requires_upload(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(78, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0079_batch_initial_007_0040_media_type_conflict_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(79, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0080_batch_initial_007_0045_chmod_requires_upload_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(80, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0081_batch_initial_007_0054_invalid_color_scheme_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(81, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0082_batch_initial_007_0057_invalid_sorting_method_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(82, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0083_batch_initial_007_0080_tls_cert_and_key_option(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(83, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0084_batch_initial_007_0081_temp_directory_requires_upload_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(84, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0085_batch_initial_007_0083_temp_directory_nonexistent_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(85, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0086_batch_initial_008_0048_repair_help_short_flag_anchor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(86, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0087_batch_initial_009_0035_corpus_auth_file_invalid_line_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(87, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0088_batch_initial_009_0040_corpus_upload_media_type_enum(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(88, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0089_batch_initial_009_0052_corpus_temp_upload_directory_invalid_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(89, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0090_batch_initial_010_0005_print_completions_powershell(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(90, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0091_batch_initial_010_0012_invalid_interface_parse(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(91, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0092_batch_initial_010_0016_random_route_conflicts_route_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(92, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0093_batch_initial_010_0017_spa_requires_index_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(93, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0094_batch_initial_010_0026_mkdir_requires_upload_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(94, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0095_batch_initial_010_0028_chmod_requires_upload_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(95, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0096_batch_initial_010_0029_chmod_invalid_octal_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(96, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0097_batch_initial_010_0031_temp_directory_requires_upload_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(97, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0098_batch_initial_010_0032_temp_directory_missing_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(98, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0099_batch_initial_010_0033_temp_directory_not_a_directory(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(99, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0100_batch_initial_010_0035_media_type_requires_upload_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(100, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0101_batch_initial_010_0037_raw_media_type_requires_upload_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(101, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0102_batch_initial_010_0038_raw_media_type_conflicts_media_type(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(102, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0103_batch_initial_010_0042_duplicate_mode_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(103, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0104_batch_initial_010_0046_auth_invalid_hash_method(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(104, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0105_batch_initial_010_0047_auth_invalid_hex_hash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(105, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0106_batch_initial_010_0048_auth_password_too_long(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(106, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0107_batch_initial_010_0050_auth_file_missing_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(107, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0108_batch_initial_010_0053_header_malformed_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(108, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0109_batch_initial_010_0056_size_display_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(109, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0110_batch_initial_011_0005_serve_healthcheck_basic_anchor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(110, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0111_batch_initial_011_0008_hidden_default_not_served(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(111, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0112_batch_initial_011_0016_index_file_served(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(112, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0113_batch_initial_011_0017_spa_fallback_missing_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(113, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0114_batch_initial_011_0018_pretty_urls_about_html(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(114, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0115_batch_initial_011_0020_route_prefix_healthcheck_prefixed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(115, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0116_batch_initial_011_0037_api_dirsize_plain(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(116, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0117_batch_initial_011_0038_api_dirsize_percent_encoded(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(117, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0118_batch_initial_011_0039_api_dirsize_exact_bytes_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(118, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0119_batch_initial_011_0040_api_dirsize_disabled_returns_placeholder(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(119, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0120_batch_initial_011_0043_archive_zip_enabled_download(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(120, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0121_batch_initial_011_0044_archive_request_forbidden_when_disabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(121, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0122_batch_initial_011_0045_archive_notfound_when_indexing_disabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(122, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0123_batch_initial_011_0048_webdav_hidden_filtered_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(123, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0124_batch_initial_012_0009_index_file_preferred_over_listing(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(124, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0125_batch_initial_012_0010_spa_fallback_nonexistent_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(125, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0126_batch_initial_012_0011_pretty_urls_about_mapping(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(126, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0127_batch_initial_012_0012_pretty_urls_strip_trailing_slash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(127, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0128_batch_initial_012_0013_disable_indexing_blocks_listing(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(128, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0129_batch_initial_012_0028_archive_zip_download_enabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(129, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0130_batch_initial_012_0029_archive_forbidden_when_disabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(130, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0131_batch_initial_012_0043_healthcheck_default_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(131, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0132_batch_initial_012_0044_api_dirsize_enabled_root(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(132, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0133_batch_initial_012_0045_api_dirsize_disabled_returns_placeholder(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(133, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0134_batch_initial_012_0046_api_dirsize_encoded_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(134, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0135_batch_initial_013_0007_cli_print_completions_elvish(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(135, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0136_batch_initial_013_0011_cli_random_route_conflicts_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(136, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0137_batch_initial_013_0012_cli_invalid_interface_parse(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(137, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0138_batch_initial_013_0013_cli_invalid_header_parse(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(138, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0139_batch_initial_013_0015_serve_healthcheck_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(139, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0140_batch_initial_013_0016_serve_healthcheck_route_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(140, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0141_batch_initial_013_0018_serve_favicon_internal_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(141, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0142_batch_initial_013_0019_serve_css_internal_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(142, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0143_batch_initial_013_0023_serve_disable_indexing_root(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(143, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0144_batch_initial_013_0024_serve_disable_indexing_archive_query(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(144, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0145_batch_initial_013_0026_serve_archive_tar_only_forbids_targz(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(145, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0146_batch_initial_013_0027_serve_archive_zip_enabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(146, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0147_batch_initial_013_0028_serve_archive_all_disabled_forbidden(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(147, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0148_batch_initial_013_0029_serve_pretty_urls_existing_html(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(148, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0149_batch_initial_013_0030_serve_pretty_urls_missing_html(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(149, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0150_batch_initial_013_0031_serve_index_file_priority(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(150, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0151_batch_initial_013_0032_serve_spa_fallback_nonexistent_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(151, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0152_batch_initial_013_0034_serve_custom_header_multiple(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(152, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0153_batch_initial_013_0043_serve_api_dirsize_enabled_human(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(153, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0154_batch_initial_013_0044_serve_api_dirsize_enabled_exact(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(154, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0155_batch_initial_013_0045_serve_api_dirsize_disabled_returns_placeholder(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(155, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0156_batch_initial_014_0000_repair_anchor_basic_healthcheck(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(156, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0157_batch_initial_014_0002_repair_anchor_favicon_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(157, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0158_batch_initial_014_0003_repair_anchor_css_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(158, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0159_batch_initial_014_0005_repair_route_prefix_healthcheck(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(159, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0160_batch_initial_014_0009_repair_index_file_served(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(160, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0161_batch_initial_014_0011_repair_spa_index_missing_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(161, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0162_batch_initial_014_0012_repair_pretty_urls_about(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(162, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0163_batch_initial_014_0013_repair_pretty_urls_trailing_slash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(163, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0164_batch_initial_014_0018_repair_disable_indexing_root(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(164, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0165_batch_initial_014_0022_repair_archives_disabled_tar_forbidden(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(165, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0166_batch_initial_014_0025_repair_archive_zip_enabled_download(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(166, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0167_batch_initial_014_0026_repair_archive_all_enabled_zip(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(167, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0168_batch_initial_014_0027_repair_archive_disabled_by_disable_indexing(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(168, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0169_batch_initial_014_0036_repair_api_dirsize_plain(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(169, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0170_batch_initial_014_0037_repair_api_dirsize_percent_encoded(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(170, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0171_batch_initial_014_0038_repair_api_dirsize_disabled_returns_placeholder(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(171, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0172_batch_initial_014_0041_repair_api_dirsize_exact_bytes_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(172, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0173_batch_initial_014_0049_repair_webdav_options_root(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(173, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0174_batch_initial_015_0004_corpus_single_file_mode_root_serves_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(174, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0175_batch_initial_015_0014_index_file_preferred_over_listing(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(175, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0176_batch_initial_015_0016_spa_missing_route_serves_index(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(176, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0177_batch_initial_015_0017_pretty_urls_about_html_mapping(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(177, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0178_batch_initial_015_0018_pretty_urls_trailing_slash_mapping(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(178, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0179_batch_initial_015_0019_pretty_urls_explicit_html_passthrough(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(179, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0180_batch_initial_015_0025_disable_indexing_root_not_found_page(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(180, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0181_batch_initial_015_0026_disable_indexing_archive_query_not_found(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(181, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0182_batch_initial_015_0029_archive_zip_enabled_download(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(182, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0183_batch_initial_015_0031_archive_request_forbidden_when_disabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(183, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0184_batch_initial_015_0043_auth_file_accept_bill_empty_password(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(184, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0185_batch_initial_015_0048_api_dirsize_enabled_plain_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(185, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0186_batch_initial_015_0049_api_dirsize_enabled_percent_encoded_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(186, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0187_batch_initial_015_0050_api_dirsize_disabled_returns_placeholder(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(187, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0188_batch_initial_016_0010_cli_random_route_conflicts_route_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(188, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0189_batch_initial_016_0011_cli_invalid_interface_parse_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(189, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0190_batch_initial_016_0013_cli_temp_directory_must_exist_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(190, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0191_batch_initial_016_0015_serve_anchor_healthcheck(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(191, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0192_batch_initial_016_0016_serve_path_from_env_miniserve_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(192, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0193_batch_initial_016_0017_serve_route_prefix_healthcheck_prefixed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(193, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0194_batch_initial_016_0022_serve_single_file_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(194, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0195_batch_initial_016_0023_serve_pretty_urls_about(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(195, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0196_batch_initial_016_0024_serve_pretty_urls_about_trailing_slash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(196, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0197_batch_initial_016_0031_serve_disable_indexing_root_not_found(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(197, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0198_batch_initial_016_0032_archive_download_tar_forbidden_when_disabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(198, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0199_batch_initial_016_0035_archive_download_zip_enabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(199, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0200_batch_initial_016_0036_archive_not_found_when_indexing_disabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(200, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0201_batch_initial_016_0046_api_dirsize_disabled_returns_placeholder(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(201, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0202_batch_initial_016_0047_api_dirsize_enabled_plain_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(202, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0203_batch_initial_016_0048_api_dirsize_enabled_percent_encoded(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(203, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0204_batch_initial_016_0054_webdav_options_request_enabled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(204, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0205_batch_initial_016_0056_internal_favicon_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(205, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)


def test_0206_batch_initial_016_0057_internal_css_route(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr, interactions, expected_interactions = _execute_case(206, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    assert interactions == expected_interactions
    _assert_observed_files(case, tmp_path)
