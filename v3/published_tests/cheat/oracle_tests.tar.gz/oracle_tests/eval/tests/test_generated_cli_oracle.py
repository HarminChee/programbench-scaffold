"""Generated black-box CLI oracle tests."""

from __future__ import annotations

import contextlib
import base64
import http.server
import json
import os
import re
import signal
import subprocess
import threading
import time
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[2]
EVAL_DIR = Path(__file__).resolve().parents[1]
MANIFEST_PATH = EVAL_DIR / "generated_cli_manifest.json"
if not MANIFEST_PATH.exists():
    MANIFEST_PATH = EVAL_DIR / "generated_yj_manifest.json"
MANIFEST = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
FIXTURE_DIR = EVAL_DIR / "fixtures" / MANIFEST.get("fixture_subdir", "generated_cli")
CASES = MANIFEST["cases"]


@contextlib.contextmanager
def _case_runtime(case: dict, tmp_path: Path):
    for relative, content in case.get("files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    for relative, content in case.get("executable_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe executable fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        target.chmod(0o755)
    for relative, content in case.get("binary_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe binary fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(base64.b64decode(content, validate=True))
    for relative, spec in case.get("repeat_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe repeated fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        segments = spec.get("segments")
        content = (
            "".join(segment.get("row", "") * int(segment.get("count", 0)) for segment in segments)
            if isinstance(segments, list)
            else spec.get("prefix", "") + spec.get("row", "") * int(spec.get("count", 0)) + spec.get("suffix", "")
        )
        encoding = str(spec.get("encoding") or "utf-8").lower()
        if encoding in {"latin-1", "latin1"}:
            target.write_bytes(content.encode("latin-1"))
        else:
            target.write_text(content, encoding="utf-8")
    git_fixture = case.get("git") or None
    if git_fixture and git_fixture.get("init") is True:
        git_env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "ProgramBench",
            "GIT_AUTHOR_EMAIL": "programbench@example.invalid",
            "GIT_COMMITTER_NAME": "ProgramBench",
            "GIT_COMMITTER_EMAIL": "programbench@example.invalid",
            "GIT_AUTHOR_DATE": "2000-01-01T00:00:00Z",
            "GIT_COMMITTER_DATE": "2000-01-01T00:00:00Z",
        }
        subprocess.run(["git", "init", "-q", "-b", git_fixture.get("branch", "main")], cwd=tmp_path, env=git_env, check=True)
        if git_fixture.get("commit_all") is not False:
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
            subprocess.run(["git", "commit", "-q", "--allow-empty", "-m", "initial"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("staged_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        if git_fixture.get("staged_files"):
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("untracked_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    for relative, mode in case.get("file_modes", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents or not target.exists():
            raise AssertionError(f"invalid file mode fixture path: {relative}")
        target.chmod(int(mode) & 0o777)
    response = case.get("http") or None
    server = None
    thread = None
    url = ""
    if response:
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path != response.get("path", "/"):
                    self.send_error(404)
                    return
                body = response.get("body", "").encode("utf-8")
                self.send_response_only(response.get("status", 200))
                for key, value in response.get("headers", {}).items():
                    self.send_header(key, value)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)

            do_POST = do_GET
            do_PUT = do_GET
            do_PATCH = do_GET
            do_DELETE = do_GET
            do_OPTIONS = do_GET
            do_HEAD = do_GET

            def log_message(self, format, *args):
                return

            def date_time_string(self, timestamp=None):
                return "Thu, 01 Jan 1970 00:00:00 GMT"

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_port}{response.get('path', '/')}"
    try:
        yield url
    finally:
        if server:
            server.shutdown()
            server.server_close()
        if thread:
            thread.join(timeout=2)


def _case_timeout(case: dict) -> float:
    timeout = float(case.get("timeout", 5))
    cap = os.environ.get("PROGRAMBENCH_CASE_TIMEOUT_CAP", "").strip()
    if cap:
        timeout = min(timeout, max(0.1, float(cap)))
    return timeout


def _execute_case(index: int, tmp_path: Path) -> tuple[dict, Path, int, bytes, bytes, bytes, bytes]:
    case = CASES[index]
    executable = WORKSPACE / "executable"
    if not executable.exists():
        raise AssertionError(f"missing executable at {executable}")

    stdin_template = (FIXTURE_DIR / case["stdin_file"]).read_bytes()
    expected_stdout = (FIXTURE_DIR / case["stdout_file"]).read_bytes()
    expected_stderr = (FIXTURE_DIR / case["stderr_file"]).read_bytes()
    env = os.environ.copy()
    env["TZ"] = "UTC"
    with _case_runtime(case, tmp_path) as http_url:
        if case.get("isolate_home_tmp") is True:
            isolated_home = tmp_path / ".case-home"
            isolated_tmp = tmp_path / ".case-tmp"
            isolated_home.mkdir(exist_ok=True)
            isolated_tmp.mkdir(exist_ok=True)
            env.update({"HOME": str(isolated_home), "TMPDIR": str(isolated_tmp)})
        env.update({key: value.replace("{http_url}", http_url) for key, value in case.get("env", {}).items()})
        argv0 = case.get("argv0", "/workspace/executable").replace("{http_url}", http_url)
        args = [item.replace("{http_url}", http_url) for item in case["args"]]
        stdin = stdin_template.replace(b"{http_url}", http_url.encode("utf-8"))
        if case.get("terminal"):
            returncode, stdout, stderr = _run_terminal(
                executable=executable,
                argv0=argv0,
                args=args,
                stdin=stdin,
                cwd=tmp_path,
                env=env,
                timeout=_case_timeout(case),
                terminal=case["terminal"],
            )
        else:
            stdin_file = None
            if case.get("stdin_regular_file") is True:
                stdin_path = tmp_path / ".programbench-stdin"
                stdin_path.write_bytes(stdin)
                stdin_file = stdin_path.open("rb")
            proc = subprocess.Popen(
                [argv0, *args],
                executable=str(executable),
                stdin=stdin_file if stdin_file is not None else subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=tmp_path,
                env=env,
                start_new_session=os.name != "nt",
            )
            try:
                stdout, stderr = proc.communicate(
                    input=None if stdin_file is not None else stdin,
                    timeout=_case_timeout(case),
                )
                if stdin_file is not None:
                    stdin_file.close()
            except subprocess.TimeoutExpired:
                if stdin_file is not None:
                    stdin_file.close()
                if os.name != "nt":
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
                proc.communicate()
                raise
            returncode = proc.returncode
        if http_url:
            encoded_url = http_url.encode("utf-8")
            encoded_host = http_url.split("://", 1)[-1].split("/", 1)[0].encode("utf-8")
            stdout = stdout.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")
            stderr = stderr.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")

    return case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr


def _run_terminal(*, executable: Path, argv0: str, args: list[str], stdin: bytes, cwd: Path,
                  env: dict[str, str], timeout: int, terminal: dict) -> tuple[int, bytes, bytes]:
    if os.name == "nt":
        raise RuntimeError("terminal cases require a Unix pseudo-terminal")
    import fcntl
    import pty
    import select
    import struct
    import termios

    kind = str(terminal.get("kind") or "generic")
    if kind not in {"generic", "iterm2", "kitty", "sixel"}:
        raise ValueError("terminal.kind must be generic, iterm2, kitty, or sixel")
    rows = max(2, min(200, int(terminal.get("rows", 24))))
    cols = max(2, min(400, int(terminal.get("cols", 80))))
    cell_width = max(1, min(100, int(terminal.get("cell_width", 10))))
    cell_height = max(1, min(100, int(terminal.get("cell_height", 20))))
    max_output = max(1024, min(16 * 1024 * 1024, int(terminal.get("max_output_bytes", 4 * 1024 * 1024))))
    stdin_delay = max(0.0, min(5.0, float(terminal.get("stdin_delay_seconds", 0))))
    run_env = dict(env)
    run_env.update({
        "TERM_PROGRAM": "iTerm.app" if kind == "iterm2" else "ProgramBench",
        "TERM": str(terminal.get("term") or "xterm-256color"),
    })
    master, slave = pty.openpty()
    attrs = termios.tcgetattr(slave)
    attrs[3] &= ~termios.ECHO
    termios.tcsetattr(slave, termios.TCSANOW, attrs)
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    proc = subprocess.Popen(
        [argv0, *args], executable=str(executable), stdin=slave, stdout=slave, stderr=slave,
        cwd=cwd, env=run_env, start_new_session=True, close_fds=True,
    )
    os.close(slave)
    def feed_stdin() -> None:
        if stdin_delay:
            time.sleep(stdin_delay)
        with contextlib.suppress(BrokenPipeError, OSError):
            if stdin:
                os.write(master, stdin)
            for event in terminal.get("input_events") or []:
                delay = max(0.0, min(5.0, float(event.get("after_seconds", 0))))
                if delay:
                    time.sleep(delay)
                os.write(master, str(event.get("data") or "").encode("utf-8"))
            if terminal.get("send_eof") is True:
                os.write(master, b"\x04")
    feeder = threading.Thread(target=feed_stdin, daemon=True)
    feeder.start()
    output = bytearray()
    responses = {b"\x1b[14t": f"\x1b[4;{rows * cell_height};{cols * cell_width}t".encode("ascii")}
    if kind == "iterm2":
        responses[b"\x1b]1337;ReportCellSize\x07"] = f"\x1b]1337;ReportCellSize={cell_height};{cell_width}\x1b\\".encode("ascii")
    if kind == "kitty":
        responses[b"\x1b_Gi=1,a=q,t=d,f=24\x1b\\"] = b"\x1b_Gi=1;OK\x1b\\"
    if kind == "sixel":
        responses[b"\x1b[c"] = b"\x1b[?62;4;c"
    responded: set[bytes] = set()
    deadline = time.monotonic() + timeout
    try:
        while proc.poll() is None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=5)
                raise subprocess.TimeoutExpired([argv0, *args], timeout, output=bytes(output))
            ready, _, _ = select.select([master], [], [], min(0.1, remaining))
            if not ready:
                continue
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            output.extend(chunk)
            if len(output) > max_output:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                raise RuntimeError("terminal case exceeded max_output_bytes")
            for query, response in responses.items():
                if query not in responded and query in output:
                    os.write(master, response)
                    responded.add(query)
        proc.wait(timeout=5)
        while True:
            ready, _, _ = select.select([master], [], [], 0.02)
            if not ready:
                break
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            if not chunk:
                break
            output.extend(chunk)
    finally:
        feeder.join(timeout=6)
        os.close(master)
    return proc.returncode, bytes(output), b""


GO_LOG_PREFIX_RE = re.compile(
    rb"(?m)^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [^ \r\n]+\.go:\d+:)? "
)
BENCH_DURATION_RE = re.compile(
    rb"(?m)^(\s*(?:Total|Slowest|Fastest|Average):\s*)[0-9.]+(\s+secs\.)$"
)
BENCH_RATE_RE = re.compile(rb"(?m)^(\s*Requests/sec:\s*)[0-9.]+$")
BENCH_HISTOGRAM_RE = re.compile(rb"(?m)^(\s*)[0-9.]+(\s+\[\d+\]\s*\|.*)$")
BENCH_LATENCY_RE = re.compile(rb"(?m)^(\s*\d+% in\s*)[0-9.]+(\s+secs\.)$")
SEVENZIP_BENCH_NUMBER_RE = re.compile(rb"(?<![A-Za-z])[+-]?\d+(?:\.\d+)?(?:[A-Za-z/%]+)?")


EPOCH_NUMBER_RE = re.compile(rb"(?<!\d)[1-3]\d{9}(?!\d)")
ANSI_ESCAPE_RE = re.compile(rb"\x1b(?:\[[0-?]*[ -/]*[@-~]|.)", re.DOTALL)
NINJA_GRAPHVIZ_ID_RE = re.compile(rb"\b0x[0-9a-fA-F]+\b")
NINJA_COMPDB_DIRECTORY_RE = re.compile(rb'("directory"\s*:\s*")[^"]*(")')
NINJA_STATS_NUMBER_RE = re.compile(rb"(?<![A-Za-z])\d+(?:\.\d+)?")


def _normalize_ninja_graphviz_ids(value: bytes) -> bytes:
    return NINJA_GRAPHVIZ_ID_RE.sub(b"0xNODE", value)


def _normalize_ninja_compdb_directory(value: bytes) -> bytes:
    return NINJA_COMPDB_DIRECTORY_RE.sub(rb'\g<1><WORKDIR>\g<2>', value)


def _normalize_ninja_stats(value: bytes) -> bytes:
    return NINJA_STATS_NUMBER_RE.sub(b"<N>", value)


def _normalize_terminal_control_tail(value: bytes) -> bytes:
    cursor = 0
    last_visible_end = 0
    for match in ANSI_ESCAPE_RE.finditer(value):
        chunk = value[cursor:match.start()]
        if chunk.strip():
            last_visible_end = match.start()
        cursor = match.end()
    if value[cursor:].strip():
        last_visible_end = len(value)
    if not last_visible_end or last_visible_end == len(value):
        return value
    return value[:last_visible_end] + b"\n<TERMINAL_CONTROL_TAIL>\n"


def _normalize_benchmark_output(value: bytes) -> bytes:
    value = BENCH_DURATION_RE.sub(rb"\g<1>0.0000\g<2>", value)
    value = BENCH_RATE_RE.sub(rb"\g<1>0.0000", value)
    value = BENCH_HISTOGRAM_RE.sub(rb"\g<1>0.000\g<2>", value)
    value = BENCH_LATENCY_RE.sub(rb"\g<1>0.0000\g<2>", value)
    if b"Compressing  |" not in value:
        return value
    lines = value.splitlines(keepends=True)
    table_index = next(i for i, line in enumerate(lines) if b"Compressing  |" in line)
    system_index = next(
        (
            i
            for i, line in enumerate(lines[:table_index])
            if line.strip().startswith((b"Compiler:", b"Linux :", b"PageSize:"))
        ),
        table_index,
    )
    lines = lines[:system_index] + [b"<SYSTEM>\n", b"\n"] + lines[table_index:]
    normalized = []
    in_table = False
    for line in lines:
        if b"Compressing  |" in line:
            in_table = True
        if in_table and any(48 <= byte <= 57 for byte in line):
            line = SEVENZIP_BENCH_NUMBER_RE.sub(b"<N>", line)
            line = b" ".join(line.split()) + b"\n"
        normalized.append(line)
    return b"".join(normalized)


TUI_WPM_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=WPM\b)")
TUI_ACC_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=% Acc\b)")


def _normalize_tui_metrics(value: bytes) -> bytes:
    value = TUI_WPM_METRIC_RE.sub(rb"\g<1><WPM>", value)
    return TUI_ACC_METRIC_RE.sub(rb"\g<1><ACC>", value)


def _assert_stdout(case: dict, stdout: bytes, expected_stdout: bytes) -> None:
    if case.get("stdout_mode") == "lines_unordered":
        assert sorted(stdout.splitlines()) == sorted(expected_stdout.splitlines())
    else:
        assert stdout == expected_stdout


def _assert_observed_files(case: dict, tmp_path: Path) -> None:
    root = tmp_path.resolve()
    for relative, expected in case.get("observed_files", {}).items():
        target = tmp_path / relative
        exists = target.exists() or target.is_symlink()
        assert exists is bool(expected.get("exists")), f"post-run existence mismatch: {relative}"
        if not exists:
            continue
        resolved = target.resolve()
        assert resolved == root or root in resolved.parents, f"post-run path escaped workspace: {relative}"
        kind = expected.get("kind")
        if kind == "directory":
            assert target.is_dir(), f"expected post-run directory: {relative}"
        elif kind == "file":
            assert target.is_file(), f"expected post-run file: {relative}"
            expected_bytes = base64.b64decode(expected.get("content_base64", ""), validate=True)
            assert target.read_bytes() == expected_bytes, f"post-run bytes mismatch: {relative}"


def _normalize_terminal_final_screen(value: bytes, *, rows: int, cols: int) -> bytes:
    """Reconstruct the final visible ANSI terminal screen for exact comparison."""

    rows = max(2, min(200, int(rows)))
    cols = max(2, min(400, int(cols)))
    screen = [[" "] * cols for _ in range(rows)]
    row = col = 0
    saved = (0, 0)
    last_screen: list[list[str]] | None = None
    text = value.decode("utf-8", "replace")

    def clear_all() -> None:
        nonlocal screen
        screen = [[" "] * cols for _ in range(rows)]

    def snapshot() -> None:
        nonlocal last_screen
        last_screen = [line[:] for line in screen]

    index = 0
    while index < len(text):
        char = text[index]
        if char == "\x1b":
            if index + 1 < len(text) and text[index + 1] == "[":
                match = re.match(r"\x1b\[([0-?]*)([ -/]*)([@-~])", text[index:])
                if match:
                    params, _, command = match.groups()
                    index += len(match.group(0))
                    private = params.startswith("?")
                    raw_params = params[1:] if private else params
                    numbers = [int(item) if item else 0 for item in raw_params.split(";")] if raw_params else []
                    first = numbers[0] if numbers else 0
                    if private and first == 1049 and command == "h":
                        clear_all()
                        row = col = 0
                    elif private and first == 1049 and command == "l":
                        snapshot()
                    elif command in {"H", "f"}:
                        row = max(0, min(rows - 1, (numbers[0] if numbers else 1) - 1))
                        col = max(0, min(cols - 1, (numbers[1] if len(numbers) > 1 else 1) - 1))
                    elif command == "A":
                        row = max(0, row - (first or 1))
                    elif command == "B":
                        row = min(rows - 1, row + (first or 1))
                    elif command == "C":
                        col = min(cols - 1, col + (first or 1))
                    elif command == "D":
                        col = max(0, col - (first or 1))
                    elif command == "E":
                        row, col = min(rows - 1, row + (first or 1)), 0
                    elif command == "F":
                        row, col = max(0, row - (first or 1)), 0
                    elif command in {"G", "`"}:
                        col = max(0, min(cols - 1, (first or 1) - 1))
                    elif command == "d":
                        row = max(0, min(rows - 1, (first or 1) - 1))
                    elif command == "J":
                        if first in {2, 3}:
                            clear_all()
                        elif first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                            for target in range(row + 1, rows):
                                screen[target] = [" "] * cols
                        elif first == 1:
                            for target in range(row):
                                screen[target] = [" "] * cols
                            screen[row][: col + 1] = [" "] * (col + 1)
                    elif command == "K":
                        if first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                        elif first == 1:
                            screen[row][: col + 1] = [" "] * (col + 1)
                        elif first == 2:
                            screen[row] = [" "] * cols
                    elif command == "s":
                        saved = (row, col)
                    elif command == "u":
                        row, col = saved
                    continue
            if index + 1 < len(text) and text[index + 1] in {"7", "8"}:
                if text[index + 1] == "7":
                    saved = (row, col)
                else:
                    row, col = saved
                index += 2
                continue
            if index + 1 < len(text) and text[index + 1] == "]":
                end_bel = text.find("\x07", index + 2)
                end_st = text.find("\x1b\\", index + 2)
                endings = [item for item in (end_bel, end_st) if item >= 0]
                index = (min(endings) + (2 if min(endings) == end_st else 1)) if endings else len(text)
                continue
            index += 2
            continue
        if char == "\r":
            col = 0
        elif char == "\n":
            row = min(rows - 1, row + 1)
        elif char == "\b":
            col = max(0, col - 1)
        elif char >= " " and char != "\x7f":
            screen[row][col] = char
            col += 1
            if col >= cols:
                col = 0
                row = min(rows - 1, row + 1)
        index += 1

    selected = last_screen or screen
    lines = ["".join(line).rstrip() for line in selected]
    while lines and not lines[-1]:
        lines.pop()
    return ("<TERMINAL_FINAL_SCREEN>\n" + "\n".join(lines) + "\n").encode("utf-8")


def test_0000_batch_01_source_and_entrypoints_0000_view_simple_sheet_from_personal_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(0, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0001_batch_01_source_and_entrypoints_0001_view_nested_cheatsheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(1, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0002_batch_01_source_and_entrypoints_0002_edit_creates_new_cheatsheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(2, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0003_batch_01_source_and_entrypoints_0005_list_filtered_by_tag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(3, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0004_batch_01_source_and_entrypoints_0007_search_phrase_ssh(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(4, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0005_batch_01_source_and_entrypoints_0008_search_regex_ip_address(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(5, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0006_batch_01_source_and_entrypoints_0009_search_colorized_output(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(6, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0007_batch_01_source_and_entrypoints_0011_list_directories(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(7, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0008_batch_01_source_and_entrypoints_0012_list_tags_in_use(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(8, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0009_batch_01_source_and_entrypoints_0013_remove_cheatsheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(9, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0010_batch_01_source_and_entrypoints_0014_update_all_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(10, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0011_batch_01_source_and_entrypoints_0015_update_specific_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(11, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0012_batch_01_source_and_entrypoints_0016_print_version(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(12, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0013_batch_01_source_and_entrypoints_0017_print_config_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(13, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0014_batch_01_source_and_entrypoints_0018_print_init_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(14, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0015_batch_01_source_and_entrypoints_0019_generate_bash_completion(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(15, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0016_batch_01_source_and_entrypoints_0020_generate_zsh_completion(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(16, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0017_batch_01_source_and_entrypoints_0021_generate_fish_completion(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(17, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0018_batch_01_source_and_entrypoints_0022_generate_powershell_completion(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(18, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0019_batch_01_source_and_entrypoints_0023_all_cheatpaths_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(19, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0020_batch_01_source_and_entrypoints_0024_view_nonexistent_cheatsheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(20, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0021_batch_01_source_and_entrypoints_0025_edit_path_traversal_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(21, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0022_batch_01_source_and_entrypoints_0026_edit_absolute_path_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(22, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0023_batch_01_source_and_entrypoints_0027_edit_tilde_path_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(23, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0024_batch_01_source_and_entrypoints_0028_edit_hidden_name_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(24, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0025_batch_01_source_and_entrypoints_0029_edit_empty_name_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(25, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0026_batch_01_source_and_entrypoints_0030_rm_path_traversal_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(26, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0027_batch_01_source_and_entrypoints_0031_rm_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(27, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0028_batch_01_source_and_entrypoints_0032_invalid_completion_shell(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(28, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0029_batch_01_source_and_entrypoints_0033_conflicting_search_flags(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(29, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0030_batch_01_source_and_entrypoints_0034_unknown_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(30, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0031_batch_01_source_and_entrypoints_0035_no_args_no_flags(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(31, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0032_batch_01_source_and_entrypoints_0036_filter_nonexistent_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(32, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0033_batch_01_source_and_entrypoints_0039_regex_search_malformed_pattern(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(33, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0034_batch_01_source_and_entrypoints_0040_list_briefly_with_name_filter(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(34, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0035_batch_01_source_and_entrypoints_0042_edit_nested_path_on_named_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(35, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0036_batch_01_source_and_entrypoints_0043_edit_dot_prefixed_current_dir_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(36, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0037_batch_01_source_and_entrypoints_0044_view_directory_scoped_cheatsheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(37, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0038_batch_01_source_and_entrypoints_0045_directories_shows_cwd_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(38, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0039_batch_01_source_and_entrypoints_0046_nearest_cheat_wins_over_ancestor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(39, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0040_batch_01_source_and_entrypoints_0048_edit_creates_directory_for_nested_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(40, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0041_batch_01_source_and_entrypoints_0049_edit_readonly_sheet_copies_to_writable(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(41, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0042_batch_01_source_and_entrypoints_0052_deep_nested_cheat_directory_discovery(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(42, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0043_batch_01_source_and_entrypoints_0055_config_generate_and_view_conf_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(43, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0044_batch_01_source_and_entrypoints_0056_custom_config_path_env_var(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(44, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0045_batch_01_source_and_entrypoints_0057_editor_env_visual_override(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(45, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0046_batch_01_source_and_entrypoints_0058_editor_env_editor_fallback(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(46, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0047_batch_01_source_and_entrypoints_0059_pager_env_var_used_for_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(47, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0048_batch_01_source_and_entrypoints_0060_xdg_config_home_override(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(48, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0049_batch_01_source_and_entrypoints_0061_missing_config_file_prompts_installer(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(49, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0050_batch_01_source_and_entrypoints_0062_first_run_accept_clone_fails_gracefully(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(50, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0051_batch_01_source_and_entrypoints_0063_empty_config_uses_defaults(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(51, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0052_batch_01_source_and_entrypoints_0064_invalid_yaml_config_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(52, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0053_batch_01_source_and_entrypoints_0065_duplicate_cheatpath_names_invalid_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(53, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0054_batch_01_source_and_entrypoints_0066_invalid_formatter_config_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(54, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0055_batch_01_source_and_entrypoints_0067_missing_cheatpaths_config_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(55, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0056_batch_01_source_and_entrypoints_0068_colorize_flag_forces_color_regardless_of_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(56, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0057_batch_01_source_and_entrypoints_0069_windows_style_appdata_config_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(57, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0058_batch_01_source_and_entrypoints_0070_search_within_timeout_bound(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(58, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0059_batch_01_source_and_entrypoints_0071_complex_regex_search_bounded_time(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(59, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0060_batch_01_source_and_entrypoints_0075_search_all_cheatpaths_multiple_dirs_timing(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(60, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0061_batch_01_source_and_entrypoints_0076_init_flag_help_short_h(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(61, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0062_batch_01_source_and_entrypoints_0077_long_help_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(62, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0063_batch_01_source_and_entrypoints_0078_tags_command_empty_result_when_no_tags(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(63, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0064_batch_01_source_and_entrypoints_0079_remove_readonly_cheatpath_sheet_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(64, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0065_batch_02_docs_and_native_behaviors_0009_list_tags_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(65, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0066_batch_02_docs_and_native_behaviors_0013_search_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(66, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0067_batch_02_docs_and_native_behaviors_0015_search_regex_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(67, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0068_batch_02_docs_and_native_behaviors_0018_list_tags_long_flag2(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(68, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0069_batch_02_docs_and_native_behaviors_0020_colorize_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(69, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0070_batch_02_docs_and_native_behaviors_0022_version_flag_long(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(70, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0071_batch_02_docs_and_native_behaviors_0025_all_flag_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(71, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0072_batch_02_docs_and_native_behaviors_0026_all_long_flag_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(72, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0073_batch_02_docs_and_native_behaviors_0032_edit_flag_long(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(73, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0074_batch_02_docs_and_native_behaviors_0033_edit_nested_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(74, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0075_batch_02_docs_and_native_behaviors_0035_update_flag_short(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(75, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0076_batch_02_docs_and_native_behaviors_0038_rm_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(76, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0077_batch_02_docs_and_native_behaviors_0041_edit_home_expansion_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(77, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0078_batch_02_docs_and_native_behaviors_0044_rm_path_traversal_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(78, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0079_batch_02_docs_and_native_behaviors_0045_completion_invalid_shell(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(79, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0080_batch_02_docs_and_native_behaviors_0046_view_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(80, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0081_batch_02_docs_and_native_behaviors_0047_list_path_nonexistent(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(81, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0082_batch_02_docs_and_native_behaviors_0050_regex_without_search_phrase(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(82, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0083_batch_02_docs_and_native_behaviors_0053_edit_deeply_nested_sheet_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(83, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0084_batch_02_docs_and_native_behaviors_0055_search_regex_unclosed_paren(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(84, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0085_batch_02_docs_and_native_behaviors_0057_conf_yml_env_override(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(85, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0086_batch_02_docs_and_native_behaviors_0060_pager_env_override(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(86, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0087_batch_02_docs_and_native_behaviors_0061_xdg_config_home_isolated(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(87, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0088_batch_02_docs_and_native_behaviors_0062_isolated_home_first_run_prompt(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(88, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0089_batch_02_docs_and_native_behaviors_0063_empty_config_yaml_defaults(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(89, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0090_batch_02_docs_and_native_behaviors_0064_config_with_duplicate_cheatpath_names(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(90, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0091_batch_02_docs_and_native_behaviors_0065_config_invalid_yaml_syntax(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(91, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0092_batch_02_docs_and_native_behaviors_0066_config_missing_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(92, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0093_batch_02_docs_and_native_behaviors_0067_config_invalid_formatter_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(93, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0094_batch_02_docs_and_native_behaviors_0068_config_path_does_not_exist_env(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(94, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0095_batch_02_docs_and_native_behaviors_0070_view_sheet_from_nested_local_cheat(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(95, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0096_batch_02_docs_and_native_behaviors_0071_view_sheet_with_yaml_frontmatter(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(96, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0097_batch_02_docs_and_native_behaviors_0072_view_sheet_no_frontmatter_plaintext(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(97, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0098_batch_02_docs_and_native_behaviors_0074_local_cheat_file_not_directory_ignored(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(98, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0099_batch_02_docs_and_native_behaviors_0075_local_cheat_directory_ending_in_dotgit_suffix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(99, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0100_batch_02_docs_and_native_behaviors_0076_list_dir_symlinked_cheat_directory(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(100, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0101_batch_02_docs_and_native_behaviors_0077_cheatpath_with_broken_symlink_skipped(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(101, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0102_batch_02_docs_and_native_behaviors_0078_load_from_nonexistent_cheatpath_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(102, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0103_batch_02_docs_and_native_behaviors_0079_edit_sheet_creates_writeable_dir_copy(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(103, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0104_batch_02_docs_and_native_behaviors_0081_update_all_cheatpaths_bounded_timeout(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(104, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0105_batch_02_docs_and_native_behaviors_0083_pull_dirty_worktree_state_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(105, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0106_batch_03_fixture_and_state_space_0000_view_missing_sheet_shows_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(106, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0107_batch_03_fixture_and_state_space_0004_conf_flag_displays_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(107, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0108_batch_03_fixture_and_state_space_0009_completion_invalid_shell_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(108, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0109_batch_03_fixture_and_state_space_0010_config_missing_generates_prompt_flow(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(109, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0110_batch_03_fixture_and_state_space_0011_unknown_flag_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(110, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0111_batch_04_blackbox_and_boundaries_0005_brief_with_tag_filter(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(111, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0112_batch_04_blackbox_and_boundaries_0017_colorize_regex_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(112, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0113_batch_04_blackbox_and_boundaries_0018_all_flag_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(113, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0114_batch_04_blackbox_and_boundaries_0019_remove_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(114, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0115_batch_04_blackbox_and_boundaries_0020_remove_path_traversal_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(115, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0116_batch_04_blackbox_and_boundaries_0025_edit_nested_hidden_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(116, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0117_batch_04_blackbox_and_boundaries_0027_edit_valid_nested_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(117, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0118_batch_04_blackbox_and_boundaries_0029_edit_just_dots_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(118, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0119_batch_04_blackbox_and_boundaries_0034_completion_invalid_shell(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(119, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0120_batch_04_blackbox_and_boundaries_0037_update_nonexistent_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(120, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0121_batch_04_blackbox_and_boundaries_0039_view_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(121, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0122_batch_04_blackbox_and_boundaries_0043_tag_filter_missing_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(122, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0123_batch_04_blackbox_and_boundaries_0044_edit_missing_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(123, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0124_batch_04_blackbox_and_boundaries_0045_rm_missing_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(124, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0125_batch_04_blackbox_and_boundaries_0047_env_editor_precedence_over_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(125, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0126_batch_04_blackbox_and_boundaries_0051_first_run_no_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(126, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0127_batch_04_blackbox_and_boundaries_0052_first_run_accept_community(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(127, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0128_batch_05_cartesian_expansion_0035_single_char_cheatsheet_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(128, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0129_batch_05_cartesian_expansion_0036_deeply_nested_cheatsheet_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(129, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0130_batch_05_cartesian_expansion_0041_path_flag_nonexistent_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(130, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0131_batch_05_cartesian_expansion_0042_completion_missing_shell_arg(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(131, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0132_batch_05_cartesian_expansion_0050_view_nonexistent_cheatsheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(132, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0133_batch_05_cartesian_expansion_0055_view_directory_scoped_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(133, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0134_batch_05_cartesian_expansion_0057_search_timing_short_regex(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(134, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0135_batch_05_cartesian_expansion_0060_update_context_timeout(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(135, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0136_batch_05_cartesian_expansion_0062_config_missing_editor_env_fallback(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(136, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0137_batch_05_cartesian_expansion_0063_config_visual_overrides_editor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(137, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0138_batch_05_cartesian_expansion_0064_config_xdg_home_override(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(138, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0139_batch_05_cartesian_expansion_0066_config_pager_env_var(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(139, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0140_batch_05_cartesian_expansion_0067_config_editor_whitespace_only(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(140, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0141_batch_05_cartesian_expansion_0068_config_pager_whitespace_only(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(141, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0142_batch_05_cartesian_expansion_0070_config_duplicate_cheatpath_names(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(142, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0143_batch_05_cartesian_expansion_0071_config_missing_formatter_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(143, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0144_batch_05_cartesian_expansion_0072_config_broken_symlink_cheatpath_skipped(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(144, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0145_batch_05_cartesian_expansion_0073_config_symlink_resolution_directories(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(145, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0146_batch_05_cartesian_expansion_0075_view_sheet_with_frontmatter_tags(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(146, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0147_batch_05_cartesian_expansion_0080_load_nonexistent_cheatpath_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(147, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0148_batch_05_cartesian_expansion_0081_sheet_with_malformed_frontmatter_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(148, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0149_batch_06_source_and_entrypoints_0004_directories_flag_list_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(149, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0150_batch_06_source_and_entrypoints_0010_first_run_installer_declines_community(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(150, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0151_batch_06_source_and_entrypoints_0011_first_run_installer_accepts_clone_attempt(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(151, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0152_batch_07_docs_and_native_behaviors_0001_view_basic_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(152, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0153_batch_07_docs_and_native_behaviors_0002_list_flag_shows_paths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(153, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0154_batch_07_docs_and_native_behaviors_0003_brief_flag_omits_paths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(154, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0155_batch_07_docs_and_native_behaviors_0004_combined_lb_matches_b(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(155, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0156_batch_07_docs_and_native_behaviors_0005_tag_filter_networking(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(156, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0157_batch_07_docs_and_native_behaviors_0006_path_filter_personal(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(157, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0158_batch_07_docs_and_native_behaviors_0007_search_basic_phrase(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(158, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0159_batch_07_docs_and_native_behaviors_0008_search_regex_ip_pattern(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(159, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0160_batch_07_docs_and_native_behaviors_0009_tags_list_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(160, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0161_batch_07_docs_and_native_behaviors_0010_directories_flag_lists_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(161, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0162_batch_07_docs_and_native_behaviors_0011_conf_flag_prints_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(162, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0163_batch_07_docs_and_native_behaviors_0015_remove_missing_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(163, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0164_batch_07_docs_and_native_behaviors_0016_rm_path_traversal_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(164, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0165_batch_07_docs_and_native_behaviors_0017_edit_path_traversal_blocked_dotdot(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(165, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0166_batch_07_docs_and_native_behaviors_0018_edit_absolute_path_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(166, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0167_batch_07_docs_and_native_behaviors_0019_edit_home_expansion_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(167, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0168_batch_07_docs_and_native_behaviors_0020_edit_hidden_file_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(168, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0169_batch_07_docs_and_native_behaviors_0021_edit_valid_nested_name_allowed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(169, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0170_batch_07_docs_and_native_behaviors_0022_edit_current_dir_prefix_allowed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(170, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0171_batch_07_docs_and_native_behaviors_0023_update_flag_no_git_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(171, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0172_batch_07_docs_and_native_behaviors_0024_update_with_path_filter_community(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(172, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0173_batch_07_docs_and_native_behaviors_0030_colorize_flag_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(173, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0174_batch_07_docs_and_native_behaviors_0031_colorize_view_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(174, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0175_batch_07_docs_and_native_behaviors_0032_all_flag_search_across_paths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(175, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0176_batch_07_docs_and_native_behaviors_0033_combined_path_tag_regex_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(176, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0177_batch_07_docs_and_native_behaviors_0035_config_missing_editor_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(177, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0178_batch_07_docs_and_native_behaviors_0036_config_duplicate_cheatpath_names_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(178, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0179_batch_07_docs_and_native_behaviors_0037_config_invalid_formatter_rejected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(179, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0180_batch_07_docs_and_native_behaviors_0038_editor_env_override_visual(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(180, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0181_batch_07_docs_and_native_behaviors_0040_dotcheat_directory_scoped_view(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(181, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0182_batch_07_docs_and_native_behaviors_0046_view_nested_sheet_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(182, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0183_batch_07_docs_and_native_behaviors_0047_edit_nested_sheet_on_named_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(183, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0184_batch_07_docs_and_native_behaviors_0049_remove_readonly_sheet_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(184, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0185_batch_07_docs_and_native_behaviors_0050_search_case_insensitive_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(185, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0186_batch_07_docs_and_native_behaviors_0051_list_and_all_flag_combined(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(186, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0187_batch_07_docs_and_native_behaviors_0054_unknown_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(187, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0188_batch_07_docs_and_native_behaviors_0055_repo_update_dirty_worktree_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(188, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0189_batch_07_docs_and_native_behaviors_0056_repo_update_clean_uptodate(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(189, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0190_batch_07_docs_and_native_behaviors_0057_view_syntax_frontmatter_colorized(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(190, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0191_batch_07_docs_and_native_behaviors_0058_view_windows_line_endings_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(191, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0192_batch_07_docs_and_native_behaviors_0059_view_malformed_frontmatter_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(192, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0193_batch_07_docs_and_native_behaviors_0060_view_malformed_yaml_in_frontmatter_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(193, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0194_batch_08_fixture_and_state_space_0041_missing_config_file_prompts_or_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(194, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0195_batch_09_blackbox_and_boundaries_0000_view_simple_flag_alias_edit_short(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(195, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0196_batch_09_blackbox_and_boundaries_0001_edit_long_form(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(196, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0197_batch_09_blackbox_and_boundaries_0002_edit_nested_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(197, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0198_batch_09_blackbox_and_boundaries_0003_edit_reject_parent_traversal(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(198, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0199_batch_09_blackbox_and_boundaries_0004_edit_reject_absolute_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(199, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0200_batch_09_blackbox_and_boundaries_0005_edit_reject_home_expansion(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(200, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0201_batch_09_blackbox_and_boundaries_0006_edit_reject_hidden_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(201, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0202_batch_09_blackbox_and_boundaries_0007_edit_allow_current_dir_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(202, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0203_batch_09_blackbox_and_boundaries_0008_edit_reject_empty_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(203, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0204_batch_09_blackbox_and_boundaries_0028_all_flag_short(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(204, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0205_batch_09_blackbox_and_boundaries_0029_all_flag_long(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(205, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0206_batch_09_blackbox_and_boundaries_0049_view_colorized_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(206, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0207_batch_09_blackbox_and_boundaries_0053_edit_with_path_scope(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(207, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0208_batch_09_blackbox_and_boundaries_0055_isolated_home_first_run_accept_prompt(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(208, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0209_batch_09_blackbox_and_boundaries_0059_pager_env_var_used(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(209, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0210_batch_09_blackbox_and_boundaries_0061_edit_and_remove_flag_conflict(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(210, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0211_batch_09_blackbox_and_boundaries_0062_directories_with_all_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(211, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0212_batch_09_blackbox_and_boundaries_0064_search_case_insensitive_regex_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(212, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0213_batch_09_blackbox_and_boundaries_0066_rm_with_nested_valid_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(213, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0214_batch_10_cartesian_expansion_0014_colorize_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(214, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0215_batch_10_cartesian_expansion_0015_search_flag_phrase(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(215, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0216_batch_10_cartesian_expansion_0016_search_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(216, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0217_batch_10_cartesian_expansion_0018_search_regex_invalid_pattern(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(217, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0218_batch_10_cartesian_expansion_0019_tag_filter_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(218, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0219_batch_10_cartesian_expansion_0021_path_filter_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(219, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0220_batch_10_cartesian_expansion_0022_path_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(220, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0221_batch_10_cartesian_expansion_0023_all_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(221, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0222_batch_10_cartesian_expansion_0024_all_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(222, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0223_batch_10_cartesian_expansion_0028_edit_flag_valid_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(223, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0224_batch_10_cartesian_expansion_0029_edit_long_flag_nested(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(224, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0225_batch_10_cartesian_expansion_0030_edit_path_traversal_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(225, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0226_batch_10_cartesian_expansion_0032_edit_home_expansion_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(226, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0227_batch_10_cartesian_expansion_0035_edit_dotdot_only_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(227, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0228_batch_10_cartesian_expansion_0036_edit_current_dir_allowed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(228, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0229_batch_10_cartesian_expansion_0037_rm_flag_valid_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(229, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0230_batch_10_cartesian_expansion_0039_rm_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(230, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0231_batch_10_cartesian_expansion_0055_xdg_config_home_env(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(231, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0232_batch_10_cartesian_expansion_0056_list_path_filter_nonexistent_path(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(232, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0233_batch_10_cartesian_expansion_0059_stdin_ignored_view(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(233, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0234_batch_10_cartesian_expansion_0060_search_phrase_with_spaces(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(234, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0235_batch_10_cartesian_expansion_0062_edit_deeply_nested_valid_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(235, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0236_batch_10_cartesian_expansion_0063_edit_nested_hidden_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(236, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0237_batch_10_cartesian_expansion_0064_rm_hidden_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(237, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0238_batch_10_cartesian_expansion_0065_conf_and_directories_together(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(238, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0239_batch_10_cartesian_expansion_0066_version_with_extra_arg(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(239, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0240_batch_10_cartesian_expansion_0067_windows_style_absolute_path_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(240, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0241_batch_11_source_and_entrypoints_0044_config_missing_prompts_installer(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(241, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0242_batch_12_docs_and_native_behaviors_0016_search_all_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(242, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0243_batch_12_docs_and_native_behaviors_0019_edit_new_cheatsheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(243, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0244_batch_12_docs_and_native_behaviors_0023_rm_short_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(244, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0245_batch_12_docs_and_native_behaviors_0031_view_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(245, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0246_batch_12_docs_and_native_behaviors_0043_rm_current_dir_prefix_allowed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(246, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0247_batch_12_docs_and_native_behaviors_0046_path_missing_value_arg(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(247, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0248_batch_12_docs_and_native_behaviors_0057_list_directories_with_tag_filter(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(248, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0249_batch_12_docs_and_native_behaviors_0059_cwd_dotcheat_view_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(249, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0250_batch_12_docs_and_native_behaviors_0061_yaml_frontmatter_syntax_and_tags(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(250, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0251_batch_12_docs_and_native_behaviors_0062_yaml_malformed_frontmatter_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(251, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0252_batch_12_docs_and_native_behaviors_0063_readonly_cheatpath_edit_copies_to_writable(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(252, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0253_batch_13_fixture_and_state_space_0004_list_flag_lists_sheets(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(253, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0254_batch_13_fixture_and_state_space_0005_brief_flag_omits_file_column(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(254, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0255_batch_13_fixture_and_state_space_0006_tags_flag_lists_all_tags(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(255, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0256_batch_13_fixture_and_state_space_0007_search_flag_finds_phrase(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(256, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0257_batch_13_fixture_and_state_space_0008_search_regex_flag_finds_ip(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(257, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0258_batch_13_fixture_and_state_space_0009_path_filter_flag_restricts_to_named_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(258, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0259_batch_13_fixture_and_state_space_0010_tag_filter_flag_restricts_to_tag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(259, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0260_batch_13_fixture_and_state_space_0011_view_missing_sheet_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(260, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0261_batch_13_fixture_and_state_space_0012_view_existing_sheet_prints_text(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(261, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0262_batch_13_fixture_and_state_space_0013_edit_reject_path_traversal_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(262, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0263_batch_13_fixture_and_state_space_0014_edit_reject_absolute_path_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(263, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0264_batch_13_fixture_and_state_space_0015_edit_reject_home_expansion_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(264, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0265_batch_13_fixture_and_state_space_0016_rm_reject_dotdot_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(265, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0266_batch_13_fixture_and_state_space_0017_rm_existing_sheet_deletes_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(266, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0267_batch_13_fixture_and_state_space_0018_update_flag_pulls_git_backed_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(267, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0268_batch_13_fixture_and_state_space_0019_update_path_filter_only_named_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(268, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0269_batch_13_fixture_and_state_space_0020_update_dirty_worktree_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(269, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0270_batch_13_fixture_and_state_space_0021_update_not_a_repo_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(270, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0271_batch_13_fixture_and_state_space_0027_all_flag_searches_all_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(271, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0272_batch_13_fixture_and_state_space_0028_colorize_flag_applies_ansi_codes(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(272, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0273_batch_13_fixture_and_state_space_0029_empty_config_uses_default_style_and_formatter(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(273, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0274_batch_13_fixture_and_state_space_0030_config_invalid_yaml_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(274, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0275_batch_13_fixture_and_state_space_0031_config_missing_editor_invalidates(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(275, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0276_batch_13_fixture_and_state_space_0032_config_duplicate_cheatpath_names_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(276, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0277_batch_13_fixture_and_state_space_0033_config_duplicate_cheatpath_paths_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(277, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0278_batch_13_fixture_and_state_space_0034_config_invalid_formatter_invalidates(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(278, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0279_batch_13_fixture_and_state_space_0035_sheet_with_yaml_frontmatter_tags_and_syntax(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(279, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0280_batch_13_fixture_and_state_space_0036_sheet_malformed_frontmatter_yaml_errors_on_list(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(280, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0281_batch_13_fixture_and_state_space_0037_sheet_windows_line_endings_frontmatter_parses(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(281, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0282_batch_13_fixture_and_state_space_0038_sheet_no_frontmatter_displays_raw_text(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(282, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0283_batch_13_fixture_and_state_space_0040_view_sheet_from_discovered_dotcheat_directory(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(283, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0284_batch_13_fixture_and_state_space_0041_nearest_dotcheat_wins_over_ancestor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(284, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0285_batch_13_fixture_and_state_space_0042_stdin_pipe_for_edit_prompt_confirmation(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(285, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0286_batch_13_fixture_and_state_space_0043_installer_first_run_declines_community_sheets(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(286, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0287_batch_13_fixture_and_state_space_0044_installer_first_run_accepts_but_clone_may_fail_offline(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(287, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0288_batch_13_fixture_and_state_space_0045_search_stdin_not_consumed_for_search_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(288, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0289_batch_13_fixture_and_state_space_0046_list_output_written_to_stdout_not_stderr(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(289, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0290_batch_13_fixture_and_state_space_0047_error_message_written_to_stderr_on_missing_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(290, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0291_batch_13_fixture_and_state_space_0048_config_env_editor_override_visual_precedence(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(291, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0292_batch_13_fixture_and_state_space_0049_config_env_editor_fallback_no_config_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(292, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0293_batch_13_fixture_and_state_space_0050_cheat_config_path_env_overrides_all_search_paths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(293, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0294_batch_13_fixture_and_state_space_0051_readonly_cheatpath_edit_copies_to_writeable(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(294, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0295_batch_13_fixture_and_state_space_0052_no_writeable_cheatpath_edit_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(295, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0296_batch_13_fixture_and_state_space_0055_multiple_cheatpaths_local_overrides_community(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(296, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0297_batch_14_blackbox_and_boundaries_0052_stdin_piped_no_tty(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(297, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0298_batch_14_blackbox_and_boundaries_0057_missing_arg_for_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(298, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0299_batch_14_blackbox_and_boundaries_0058_missing_arg_for_edit(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(299, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0300_batch_14_blackbox_and_boundaries_0066_init_output_redirect_to_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(300, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0301_batch_14_blackbox_and_boundaries_0069_multiple_positional_args(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(301, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0302_batch_15_cartesian_expansion_0031_no_args_first_run_prompt(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(302, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0303_batch_15_cartesian_expansion_0032_no_args_first_run_prompt_yes(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(303, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0304_batch_15_cartesian_expansion_0037_path_flag_missing_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(304, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0305_batch_15_cartesian_expansion_0038_tag_flag_missing_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(305, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0306_batch_15_cartesian_expansion_0039_cmd_conf_with_valid_empty_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(306, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0307_batch_15_cartesian_expansion_0040_directories_with_valid_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(307, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0308_batch_15_cartesian_expansion_0041_list_with_valid_config_and_sheets(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(308, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0309_batch_15_cartesian_expansion_0042_view_sheet_with_valid_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(309, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0310_batch_15_cartesian_expansion_0043_view_nested_sheet_with_valid_config(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(310, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0311_batch_15_cartesian_expansion_0044_tags_list_with_valid_sheets(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(311, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0312_batch_15_cartesian_expansion_0045_search_with_valid_config_match(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(312, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0313_batch_15_cartesian_expansion_0047_list_filtered_by_tag_with_fixture(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(313, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0314_batch_15_cartesian_expansion_0048_list_filtered_by_path_with_fixture(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(314, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0315_batch_15_cartesian_expansion_0053_rm_readonly_sheet_fails(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(315, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0316_batch_15_cartesian_expansion_0054_colorize_view_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(316, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0317_batch_15_cartesian_expansion_0056_view_sheet_from_dotcheat_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(317, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0318_batch_15_cartesian_expansion_0057_config_yaml_invalid_syntax(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(318, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0319_batch_15_cartesian_expansion_0058_config_missing_editor_validation_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(319, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0320_batch_15_cartesian_expansion_0059_config_duplicate_cheatpath_names(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(320, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0321_batch_15_cartesian_expansion_0060_config_invalid_formatter(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(321, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0322_batch_15_cartesian_expansion_0061_list_directories_git_backed_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(322, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0323_batch_15_cartesian_expansion_0062_update_git_backed_cheatpath_clean(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(323, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0324_batch_15_cartesian_expansion_0063_update_git_backed_cheatpath_dirty(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(324, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0325_batch_15_cartesian_expansion_0064_view_sheet_syntax_python_colorized(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(325, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0326_batch_15_cartesian_expansion_0065_view_sheet_default_syntax_bash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(326, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0327_batch_15_cartesian_expansion_0066_view_sheet_malformed_frontmatter(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(327, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0328_batch_15_cartesian_expansion_0067_list_hidden_files_excluded(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(328, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0329_batch_15_cartesian_expansion_0068_list_files_with_extension_excluded(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(329, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0330_batch_15_cartesian_expansion_0069_list_git_dir_files_excluded(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(330, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0331_batch_15_cartesian_expansion_0070_search_across_multiple_cheatpaths(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(331, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0332_batch_15_cartesian_expansion_0071_list_briefly_multiple_tags_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(332, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0333_batch_15_cartesian_expansion_0072_search_case_insensitive_match(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(333, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0334_batch_16_source_and_entrypoints_0020_search_all_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(334, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0335_batch_16_source_and_entrypoints_0053_list_all_and_tag_combo(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(335, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0336_batch_16_source_and_entrypoints_0054_search_with_search_and_path_combo(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(336, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0337_batch_16_source_and_entrypoints_0059_multiple_tag_flags_combo(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(337, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0338_batch_16_source_and_entrypoints_0060_edit_path_flag_writable_cheatpath(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(338, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0339_batch_16_source_and_entrypoints_0062_search_case_insensitive_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(339, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0340_batch_16_source_and_entrypoints_0063_path_filter_nonexistent_cheatpath_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(340, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0341_batch_16_source_and_entrypoints_0064_init_with_conf_flag_combo_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(341, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0342_batch_16_source_and_entrypoints_0065_version_ignores_extra_args(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(342, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0343_batch_16_source_and_entrypoints_0068_view_sheet_from_dotcheat_directory(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(343, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0344_batch_16_source_and_entrypoints_0072_list_directories_and_search_conflict(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(344, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0345_batch_17_docs_and_native_behaviors_0020_search_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(345, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0346_batch_17_docs_and_native_behaviors_0047_no_args_first_run_prompt(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(346, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0347_batch_17_docs_and_native_behaviors_0048_no_args_first_run_decline(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(347, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0348_batch_17_docs_and_native_behaviors_0049_first_run_prompt_uppercase_yes(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(348, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0349_batch_17_docs_and_native_behaviors_0050_first_run_prompt_empty_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(349, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0350_batch_17_docs_and_native_behaviors_0052_path_filter_nonexistent_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(350, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0351_batch_17_docs_and_native_behaviors_0065_conf_and_init_mutually_used(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(351, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0352_batch_17_docs_and_native_behaviors_0068_edit_sheet_readonly_path_copies(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(352, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0353_batch_17_docs_and_native_behaviors_0069_rm_nested_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(353, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0354_batch_17_docs_and_native_behaviors_0072_directories_brief_combo_invalid(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(354, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0355_batch_18_fixture_and_state_space_0021_rm_nonexistent_sheet_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(355, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0356_batch_18_fixture_and_state_space_0022_view_nonexistent_sheet_returns_2(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(356, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0357_batch_18_fixture_and_state_space_0033_missing_config_triggers_installer_prompt(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(357, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0358_batch_18_fixture_and_state_space_0034_missing_config_decline_installer(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(358, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0359_batch_18_fixture_and_state_space_0035_empty_stdin_prompt_yes_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(359, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0360_batch_18_fixture_and_state_space_0036_prompt_uppercase_y_accepted(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(360, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0361_batch_18_fixture_and_state_space_0049_local_cheat_dir_discovered_from_subdir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(361, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0362_batch_18_fixture_and_state_space_0051_local_cheat_file_not_directory_ignored(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(362, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0363_batch_19_blackbox_and_boundaries_0024_path_filter_nonexistent(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(363, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0364_batch_19_blackbox_and_boundaries_0026_tag_filter_flag_long(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(364, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0365_batch_19_blackbox_and_boundaries_0043_remove_flag_existing(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(365, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0366_batch_19_blackbox_and_boundaries_0045_remove_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(366, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0367_batch_19_blackbox_and_boundaries_0053_view_nonexistent_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(367, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0368_batch_19_blackbox_and_boundaries_0059_env_xdg_config_home_used(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(368, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0369_batch_19_blackbox_and_boundaries_0065_windows_line_endings_sheet(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(369, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0370_batch_19_blackbox_and_boundaries_0069_search_case_insensitive_match(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(370, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0371_batch_19_blackbox_and_boundaries_0070_conf_style_default_bw(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(371, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0372_batch_20_cartesian_expansion_0015_tag_filter_flag_long(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(372, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0373_batch_20_cartesian_expansion_0032_edit_flag_long_valid_name(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(373, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0374_batch_20_cartesian_expansion_0043_rm_flag_nested_hidden_blocked(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(374, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0375_batch_20_cartesian_expansion_0052_nonexistent_sheet_view(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(375, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0376_batch_20_cartesian_expansion_0055_env_editor_override_view(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(376, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0377_batch_20_cartesian_expansion_0056_env_visual_override_view(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(377, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0378_batch_20_cartesian_expansion_0057_env_pager_override_search(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(378, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0379_batch_20_cartesian_expansion_0060_config_yaml_frontmatter_view(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(379, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0380_batch_20_cartesian_expansion_0061_config_yaml_windows_line_endings(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(380, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0381_batch_20_cartesian_expansion_0072_init_output_redirect_to_conf_style(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(381, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)
