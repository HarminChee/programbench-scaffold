"""Generated black-box CLI oracle tests."""

from __future__ import annotations

import contextlib
import base64
import http.server
import json
import os
import re
import signal
import subprocess
import threading
import time
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[2]
EVAL_DIR = Path(__file__).resolve().parents[1]
MANIFEST_PATH = EVAL_DIR / "generated_cli_manifest.json"
if not MANIFEST_PATH.exists():
    MANIFEST_PATH = EVAL_DIR / "generated_yj_manifest.json"
MANIFEST = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
FIXTURE_DIR = EVAL_DIR / "fixtures" / MANIFEST.get("fixture_subdir", "generated_cli")
CASES = MANIFEST["cases"]


@contextlib.contextmanager
def _case_runtime(case: dict, tmp_path: Path):
    for relative, content in case.get("files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    for relative, content in case.get("executable_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe executable fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        target.chmod(0o755)
    for relative, content in case.get("binary_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe binary fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(base64.b64decode(content, validate=True))
    for relative, spec in case.get("repeat_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe repeated fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        segments = spec.get("segments")
        content = (
            "".join(segment.get("row", "") * int(segment.get("count", 0)) for segment in segments)
            if isinstance(segments, list)
            else spec.get("prefix", "") + spec.get("row", "") * int(spec.get("count", 0)) + spec.get("suffix", "")
        )
        encoding = str(spec.get("encoding") or "utf-8").lower()
        if encoding in {"latin-1", "latin1"}:
            target.write_bytes(content.encode("latin-1"))
        else:
            target.write_text(content, encoding="utf-8")
    git_fixture = case.get("git") or None
    if git_fixture and git_fixture.get("init") is True:
        git_env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "ProgramBench",
            "GIT_AUTHOR_EMAIL": "programbench@example.invalid",
            "GIT_COMMITTER_NAME": "ProgramBench",
            "GIT_COMMITTER_EMAIL": "programbench@example.invalid",
            "GIT_AUTHOR_DATE": "2000-01-01T00:00:00Z",
            "GIT_COMMITTER_DATE": "2000-01-01T00:00:00Z",
        }
        subprocess.run(["git", "init", "-q", "-b", git_fixture.get("branch", "main")], cwd=tmp_path, env=git_env, check=True)
        if git_fixture.get("commit_all") is not False:
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
            subprocess.run(["git", "commit", "-q", "--allow-empty", "-m", "initial"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("staged_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        if git_fixture.get("staged_files"):
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("untracked_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    for relative, mode in case.get("file_modes", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents or not target.exists():
            raise AssertionError(f"invalid file mode fixture path: {relative}")
        target.chmod(int(mode) & 0o777)
    response = case.get("http") or None
    server = None
    thread = None
    url = ""
    if response:
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path != response.get("path", "/"):
                    self.send_error(404)
                    return
                body = response.get("body", "").encode("utf-8")
                self.send_response_only(response.get("status", 200))
                for key, value in response.get("headers", {}).items():
                    self.send_header(key, value)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)

            do_POST = do_GET
            do_PUT = do_GET
            do_PATCH = do_GET
            do_DELETE = do_GET
            do_OPTIONS = do_GET
            do_HEAD = do_GET

            def log_message(self, format, *args):
                return

            def date_time_string(self, timestamp=None):
                return "Thu, 01 Jan 1970 00:00:00 GMT"

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_port}{response.get('path', '/')}"
    try:
        yield url
    finally:
        if server:
            server.shutdown()
            server.server_close()
        if thread:
            thread.join(timeout=2)


def _case_timeout(case: dict) -> float:
    timeout = float(case.get("timeout", 5))
    cap = os.environ.get("PROGRAMBENCH_CASE_TIMEOUT_CAP", "").strip()
    if cap:
        timeout = min(timeout, max(0.1, float(cap)))
    return timeout


def _execute_case(index: int, tmp_path: Path) -> tuple[dict, Path, int, bytes, bytes, bytes, bytes]:
    case = CASES[index]
    executable = WORKSPACE / "executable"
    if not executable.exists():
        raise AssertionError(f"missing executable at {executable}")

    stdin_template = (FIXTURE_DIR / case["stdin_file"]).read_bytes()
    expected_stdout = (FIXTURE_DIR / case["stdout_file"]).read_bytes()
    expected_stderr = (FIXTURE_DIR / case["stderr_file"]).read_bytes()
    env = os.environ.copy()
    env["TZ"] = "UTC"
    with _case_runtime(case, tmp_path) as http_url:
        if case.get("isolate_home_tmp") is True:
            isolated_home = tmp_path / ".case-home"
            isolated_tmp = tmp_path / ".case-tmp"
            isolated_home.mkdir(exist_ok=True)
            isolated_tmp.mkdir(exist_ok=True)
            env.update({"HOME": str(isolated_home), "TMPDIR": str(isolated_tmp)})
        env.update({key: value.replace("{http_url}", http_url) for key, value in case.get("env", {}).items()})
        argv0 = case.get("argv0", "/workspace/executable").replace("{http_url}", http_url)
        args = [item.replace("{http_url}", http_url) for item in case["args"]]
        stdin = stdin_template.replace(b"{http_url}", http_url.encode("utf-8"))
        if case.get("terminal"):
            returncode, stdout, stderr = _run_terminal(
                executable=executable,
                argv0=argv0,
                args=args,
                stdin=stdin,
                cwd=tmp_path,
                env=env,
                timeout=_case_timeout(case),
                terminal=case["terminal"],
            )
        else:
            stdin_file = None
            if case.get("stdin_regular_file") is True:
                stdin_path = tmp_path / ".programbench-stdin"
                stdin_path.write_bytes(stdin)
                stdin_file = stdin_path.open("rb")
            proc = subprocess.Popen(
                [argv0, *args],
                executable=str(executable),
                stdin=stdin_file if stdin_file is not None else subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=tmp_path,
                env=env,
                start_new_session=os.name != "nt",
            )
            try:
                stdout, stderr = proc.communicate(
                    input=None if stdin_file is not None else stdin,
                    timeout=_case_timeout(case),
                )
                if stdin_file is not None:
                    stdin_file.close()
            except subprocess.TimeoutExpired:
                if stdin_file is not None:
                    stdin_file.close()
                if os.name != "nt":
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
                proc.communicate()
                raise
            returncode = proc.returncode
        if http_url:
            encoded_url = http_url.encode("utf-8")
            encoded_host = http_url.split("://", 1)[-1].split("/", 1)[0].encode("utf-8")
            stdout = stdout.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")
            stderr = stderr.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")

    return case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr


def _run_terminal(*, executable: Path, argv0: str, args: list[str], stdin: bytes, cwd: Path,
                  env: dict[str, str], timeout: int, terminal: dict) -> tuple[int, bytes, bytes]:
    if os.name == "nt":
        raise RuntimeError("terminal cases require a Unix pseudo-terminal")
    import fcntl
    import pty
    import select
    import struct
    import termios

    kind = str(terminal.get("kind") or "generic")
    if kind not in {"generic", "iterm2", "kitty", "sixel"}:
        raise ValueError("terminal.kind must be generic, iterm2, kitty, or sixel")
    rows = max(2, min(200, int(terminal.get("rows", 24))))
    cols = max(2, min(400, int(terminal.get("cols", 80))))
    cell_width = max(1, min(100, int(terminal.get("cell_width", 10))))
    cell_height = max(1, min(100, int(terminal.get("cell_height", 20))))
    max_output = max(1024, min(16 * 1024 * 1024, int(terminal.get("max_output_bytes", 4 * 1024 * 1024))))
    stdin_delay = max(0.0, min(5.0, float(terminal.get("stdin_delay_seconds", 0))))
    run_env = dict(env)
    run_env.update({
        "TERM_PROGRAM": "iTerm.app" if kind == "iterm2" else "ProgramBench",
        "TERM": str(terminal.get("term") or "xterm-256color"),
    })
    master, slave = pty.openpty()
    attrs = termios.tcgetattr(slave)
    attrs[3] &= ~termios.ECHO
    termios.tcsetattr(slave, termios.TCSANOW, attrs)
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    proc = subprocess.Popen(
        [argv0, *args], executable=str(executable), stdin=slave, stdout=slave, stderr=slave,
        cwd=cwd, env=run_env, start_new_session=True, close_fds=True,
    )
    os.close(slave)
    def feed_stdin() -> None:
        if stdin_delay:
            time.sleep(stdin_delay)
        with contextlib.suppress(BrokenPipeError, OSError):
            if stdin:
                os.write(master, stdin)
            for event in terminal.get("input_events") or []:
                delay = max(0.0, min(5.0, float(event.get("after_seconds", 0))))
                if delay:
                    time.sleep(delay)
                os.write(master, str(event.get("data") or "").encode("utf-8"))
            if terminal.get("send_eof") is True:
                os.write(master, b"\x04")
    feeder = threading.Thread(target=feed_stdin, daemon=True)
    feeder.start()
    output = bytearray()
    responses = {b"\x1b[14t": f"\x1b[4;{rows * cell_height};{cols * cell_width}t".encode("ascii")}
    if kind == "iterm2":
        responses[b"\x1b]1337;ReportCellSize\x07"] = f"\x1b]1337;ReportCellSize={cell_height};{cell_width}\x1b\\".encode("ascii")
    if kind == "kitty":
        responses[b"\x1b_Gi=1,a=q,t=d,f=24\x1b\\"] = b"\x1b_Gi=1;OK\x1b\\"
    if kind == "sixel":
        responses[b"\x1b[c"] = b"\x1b[?62;4;c"
    responded: set[bytes] = set()
    deadline = time.monotonic() + timeout
    try:
        while proc.poll() is None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=5)
                raise subprocess.TimeoutExpired([argv0, *args], timeout, output=bytes(output))
            ready, _, _ = select.select([master], [], [], min(0.1, remaining))
            if not ready:
                continue
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            output.extend(chunk)
            if len(output) > max_output:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                raise RuntimeError("terminal case exceeded max_output_bytes")
            for query, response in responses.items():
                if query not in responded and query in output:
                    os.write(master, response)
                    responded.add(query)
        proc.wait(timeout=5)
        while True:
            ready, _, _ = select.select([master], [], [], 0.02)
            if not ready:
                break
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            if not chunk:
                break
            output.extend(chunk)
    finally:
        feeder.join(timeout=6)
        os.close(master)
    return proc.returncode, bytes(output), b""


GO_LOG_PREFIX_RE = re.compile(
    rb"(?m)^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [^ \r\n]+\.go:\d+:)? "
)
BENCH_DURATION_RE = re.compile(
    rb"(?m)^(\s*(?:Total|Slowest|Fastest|Average):\s*)[0-9.]+(\s+secs\.)$"
)
BENCH_RATE_RE = re.compile(rb"(?m)^(\s*Requests/sec:\s*)[0-9.]+$")
BENCH_HISTOGRAM_RE = re.compile(rb"(?m)^(\s*)[0-9.]+(\s+\[\d+\]\s*\|.*)$")
BENCH_LATENCY_RE = re.compile(rb"(?m)^(\s*\d+% in\s*)[0-9.]+(\s+secs\.)$")
SEVENZIP_BENCH_NUMBER_RE = re.compile(rb"(?<![A-Za-z])[+-]?\d+(?:\.\d+)?(?:[A-Za-z/%]+)?")


EPOCH_NUMBER_RE = re.compile(rb"(?<!\d)[1-3]\d{9}(?!\d)")
ANSI_ESCAPE_RE = re.compile(rb"\x1b(?:\[[0-?]*[ -/]*[@-~]|.)", re.DOTALL)
NINJA_GRAPHVIZ_ID_RE = re.compile(rb"\b0x[0-9a-fA-F]+\b")
NINJA_COMPDB_DIRECTORY_RE = re.compile(rb'("directory"\s*:\s*")[^"]*(")')
NINJA_STATS_NUMBER_RE = re.compile(rb"(?<![A-Za-z])\d+(?:\.\d+)?")


def _normalize_ninja_graphviz_ids(value: bytes) -> bytes:
    return NINJA_GRAPHVIZ_ID_RE.sub(b"0xNODE", value)


def _normalize_ninja_compdb_directory(value: bytes) -> bytes:
    return NINJA_COMPDB_DIRECTORY_RE.sub(rb'\g<1><WORKDIR>\g<2>', value)


def _normalize_ninja_stats(value: bytes) -> bytes:
    return NINJA_STATS_NUMBER_RE.sub(b"<N>", value)


def _normalize_terminal_control_tail(value: bytes) -> bytes:
    cursor = 0
    last_visible_end = 0
    for match in ANSI_ESCAPE_RE.finditer(value):
        chunk = value[cursor:match.start()]
        if chunk.strip():
            last_visible_end = match.start()
        cursor = match.end()
    if value[cursor:].strip():
        last_visible_end = len(value)
    if not last_visible_end or last_visible_end == len(value):
        return value
    return value[:last_visible_end] + b"\n<TERMINAL_CONTROL_TAIL>\n"


def _normalize_benchmark_output(value: bytes) -> bytes:
    value = BENCH_DURATION_RE.sub(rb"\g<1>0.0000\g<2>", value)
    value = BENCH_RATE_RE.sub(rb"\g<1>0.0000", value)
    value = BENCH_HISTOGRAM_RE.sub(rb"\g<1>0.000\g<2>", value)
    value = BENCH_LATENCY_RE.sub(rb"\g<1>0.0000\g<2>", value)
    if b"Compressing  |" not in value:
        return value
    lines = value.splitlines(keepends=True)
    table_index = next(i for i, line in enumerate(lines) if b"Compressing  |" in line)
    system_index = next(
        (
            i
            for i, line in enumerate(lines[:table_index])
            if line.strip().startswith((b"Compiler:", b"Linux :", b"PageSize:"))
        ),
        table_index,
    )
    lines = lines[:system_index] + [b"<SYSTEM>\n", b"\n"] + lines[table_index:]
    normalized = []
    in_table = False
    for line in lines:
        if b"Compressing  |" in line:
            in_table = True
        if in_table and any(48 <= byte <= 57 for byte in line):
            line = SEVENZIP_BENCH_NUMBER_RE.sub(b"<N>", line)
            line = b" ".join(line.split()) + b"\n"
        normalized.append(line)
    return b"".join(normalized)


TUI_WPM_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=WPM\b)")
TUI_ACC_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=% Acc\b)")


def _normalize_tui_metrics(value: bytes) -> bytes:
    value = TUI_WPM_METRIC_RE.sub(rb"\g<1><WPM>", value)
    return TUI_ACC_METRIC_RE.sub(rb"\g<1><ACC>", value)


def _assert_stdout(case: dict, stdout: bytes, expected_stdout: bytes) -> None:
    if case.get("stdout_mode") == "lines_unordered":
        assert sorted(stdout.splitlines()) == sorted(expected_stdout.splitlines())
    else:
        assert stdout == expected_stdout


def _assert_observed_files(case: dict, tmp_path: Path) -> None:
    root = tmp_path.resolve()
    for relative, expected in case.get("observed_files", {}).items():
        target = tmp_path / relative
        exists = target.exists() or target.is_symlink()
        assert exists is bool(expected.get("exists")), f"post-run existence mismatch: {relative}"
        if not exists:
            continue
        resolved = target.resolve()
        assert resolved == root or root in resolved.parents, f"post-run path escaped workspace: {relative}"
        kind = expected.get("kind")
        if kind == "directory":
            assert target.is_dir(), f"expected post-run directory: {relative}"
        elif kind == "file":
            assert target.is_file(), f"expected post-run file: {relative}"
            expected_bytes = base64.b64decode(expected.get("content_base64", ""), validate=True)
            assert target.read_bytes() == expected_bytes, f"post-run bytes mismatch: {relative}"


def _normalize_terminal_final_screen(value: bytes, *, rows: int, cols: int) -> bytes:
    """Reconstruct the final visible ANSI terminal screen for exact comparison."""

    rows = max(2, min(200, int(rows)))
    cols = max(2, min(400, int(cols)))
    screen = [[" "] * cols for _ in range(rows)]
    row = col = 0
    saved = (0, 0)
    last_screen: list[list[str]] | None = None
    text = value.decode("utf-8", "replace")

    def clear_all() -> None:
        nonlocal screen
        screen = [[" "] * cols for _ in range(rows)]

    def snapshot() -> None:
        nonlocal last_screen
        last_screen = [line[:] for line in screen]

    index = 0
    while index < len(text):
        char = text[index]
        if char == "\x1b":
            if index + 1 < len(text) and text[index + 1] == "[":
                match = re.match(r"\x1b\[([0-?]*)([ -/]*)([@-~])", text[index:])
                if match:
                    params, _, command = match.groups()
                    index += len(match.group(0))
                    private = params.startswith("?")
                    raw_params = params[1:] if private else params
                    numbers = [int(item) if item else 0 for item in raw_params.split(";")] if raw_params else []
                    first = numbers[0] if numbers else 0
                    if private and first == 1049 and command == "h":
                        clear_all()
                        row = col = 0
                    elif private and first == 1049 and command == "l":
                        snapshot()
                    elif command in {"H", "f"}:
                        row = max(0, min(rows - 1, (numbers[0] if numbers else 1) - 1))
                        col = max(0, min(cols - 1, (numbers[1] if len(numbers) > 1 else 1) - 1))
                    elif command == "A":
                        row = max(0, row - (first or 1))
                    elif command == "B":
                        row = min(rows - 1, row + (first or 1))
                    elif command == "C":
                        col = min(cols - 1, col + (first or 1))
                    elif command == "D":
                        col = max(0, col - (first or 1))
                    elif command == "E":
                        row, col = min(rows - 1, row + (first or 1)), 0
                    elif command == "F":
                        row, col = max(0, row - (first or 1)), 0
                    elif command in {"G", "`"}:
                        col = max(0, min(cols - 1, (first or 1) - 1))
                    elif command == "d":
                        row = max(0, min(rows - 1, (first or 1) - 1))
                    elif command == "J":
                        if first in {2, 3}:
                            clear_all()
                        elif first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                            for target in range(row + 1, rows):
                                screen[target] = [" "] * cols
                        elif first == 1:
                            for target in range(row):
                                screen[target] = [" "] * cols
                            screen[row][: col + 1] = [" "] * (col + 1)
                    elif command == "K":
                        if first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                        elif first == 1:
                            screen[row][: col + 1] = [" "] * (col + 1)
                        elif first == 2:
                            screen[row] = [" "] * cols
                    elif command == "s":
                        saved = (row, col)
                    elif command == "u":
                        row, col = saved
                    continue
            if index + 1 < len(text) and text[index + 1] in {"7", "8"}:
                if text[index + 1] == "7":
                    saved = (row, col)
                else:
                    row, col = saved
                index += 2
                continue
            if index + 1 < len(text) and text[index + 1] == "]":
                end_bel = text.find("\x07", index + 2)
                end_st = text.find("\x1b\\", index + 2)
                endings = [item for item in (end_bel, end_st) if item >= 0]
                index = (min(endings) + (2 if min(endings) == end_st else 1)) if endings else len(text)
                continue
            index += 2
            continue
        if char == "\r":
            col = 0
        elif char == "\n":
            row = min(rows - 1, row + 1)
        elif char == "\b":
            col = max(0, col - 1)
        elif char >= " " and char != "\x7f":
            screen[row][col] = char
            col += 1
            if col >= cols:
                col = 0
                row = min(rows - 1, row + 1)
        index += 1

    selected = last_screen or screen
    lines = ["".join(line).rstrip() for line in selected]
    while lines and not lines[-1]:
        lines.pop()
    return ("<TERMINAL_FINAL_SCREEN>\n" + "\n".join(lines) + "\n").encode("utf-8")


def test_0000_batch_01_source_and_entrypoints_0000_default_run_current_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(0, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0001_batch_01_source_and_entrypoints_0001_help_flag_usage(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(1, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0002_batch_01_source_and_entrypoints_0002_threshold_long_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(2, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0003_batch_01_source_and_entrypoints_0003_threshold_short_alias(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(3, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0004_batch_01_source_and_entrypoints_0006_html_output_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(4, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0005_batch_01_source_and_entrypoints_0009_vendor_flag_included(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(5, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0006_batch_01_source_and_entrypoints_0012_files_flag_empty_stdin(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(6, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0007_batch_01_source_and_entrypoints_0014_single_file_path_direct(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(7, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0008_batch_01_source_and_entrypoints_0016_directory_recursive_go_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(8, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0009_batch_01_source_and_entrypoints_0017_multiple_paths_args(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(9, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0010_batch_01_source_and_entrypoints_0018_duplicate_clone_detection_default_threshold(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(10, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0011_batch_01_source_and_entrypoints_0019_high_threshold_no_clones(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(11, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0012_batch_01_source_and_entrypoints_0020_threshold_zero_boundary(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(12, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0013_batch_01_source_and_entrypoints_0021_negative_threshold_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(13, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0014_batch_01_source_and_entrypoints_0022_unknown_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(14, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0015_batch_01_source_and_entrypoints_0023_threshold_non_numeric_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(15, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0016_batch_01_source_and_entrypoints_0024_html_output_with_actual_clone_content(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(16, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0017_batch_01_source_and_entrypoints_0025_plumbing_output_multiple_clones_ordering(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(17, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0018_batch_01_source_and_entrypoints_0026_vendor_dir_excluded_by_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(18, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0019_batch_01_source_and_entrypoints_0033_large_threshold_exact_boundary_match(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(19, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0020_batch_01_source_and_entrypoints_0035_identical_file_twice_same_content(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(20, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0021_batch_01_source_and_entrypoints_0036_three_way_clone_group(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(21, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0022_batch_01_source_and_entrypoints_0037_tab_indented_source_for_deindent(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(22, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0023_batch_01_source_and_entrypoints_0038_crlf_line_endings_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(23, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0024_batch_01_source_and_entrypoints_0039_html_output_special_chars_escaping(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(24, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0025_batch_01_source_and_entrypoints_0047_comments_only_ignored_by_ast(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(25, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0026_batch_01_source_and_entrypoints_0048_different_identifier_names_same_structure(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(26, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0027_batch_01_source_and_entrypoints_0056_clone_at_exact_threshold_length(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(27, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0028_batch_02_docs_and_native_behaviors_0016_unknown_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(28, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0029_batch_02_docs_and_native_behaviors_0019_duplicate_code_detection_two_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(29, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0030_batch_02_docs_and_native_behaviors_0020_duplicate_detection_html_output_fragment(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(30, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0031_batch_02_docs_and_native_behaviors_0021_duplicate_detection_plumbing_output_format(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(31, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0032_batch_02_docs_and_native_behaviors_0025_vendor_directory_included_with_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(32, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0033_batch_02_docs_and_native_behaviors_0030_concurrency_multiple_files_pipeline(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(33, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0034_batch_02_docs_and_native_behaviors_0032_concurrency_large_file_set_ordering(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(34, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0035_batch_02_docs_and_native_behaviors_0033_text_printer_multiple_clone_groups_footer_count(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(35, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0036_batch_02_docs_and_native_behaviors_0034_html_escaping_special_characters_in_fragment(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(36, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0037_batch_02_docs_and_native_behaviors_0035_html_indentation_deindent_tabs(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(37, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0038_batch_02_docs_and_native_behaviors_0036_single_clone_pair_lineno_reporting(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(38, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0039_batch_02_docs_and_native_behaviors_0038_cyclic_pattern_redundant_clone_suppressed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(39, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0040_batch_02_docs_and_native_behaviors_0043_combined_vendor_and_html(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(40, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0041_batch_02_docs_and_native_behaviors_0046_plumbing_single_clone_pair_wraparound(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(41, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0042_batch_02_docs_and_native_behaviors_0047_html_multiple_separate_clone_groups_headers(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(42, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0043_batch_02_docs_and_native_behaviors_0048_duplicate_across_three_files_group_size(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(43, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0044_batch_02_docs_and_native_behaviors_0049_unique_dedup_same_position_not_double_counted(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(44, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0045_batch_04_blackbox_and_boundaries_0013_unknown_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(45, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0046_batch_04_blackbox_and_boundaries_0014_threshold_non_numeric_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(46, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0047_batch_04_blackbox_and_boundaries_0030_duplicate_code_two_files_text(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(47, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0048_batch_04_blackbox_and_boundaries_0032_three_file_group_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(48, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0049_batch_04_blackbox_and_boundaries_0033_html_output_escapes_special_chars(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(49, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0050_batch_04_blackbox_and_boundaries_0034_plumbing_output_format_lines(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(50, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0051_batch_04_blackbox_and_boundaries_0035_text_output_default_format(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(51, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0052_batch_04_blackbox_and_boundaries_0036_html_indentation_deindent_tabs(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(52, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0053_batch_04_blackbox_and_boundaries_0037_empty_clone_group_html_header_only(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(53, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0054_batch_04_blackbox_and_boundaries_0041_read_file_error_during_html_render(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(54, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0055_batch_04_blackbox_and_boundaries_0042_help_long_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(55, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0056_batch_04_blackbox_and_boundaries_0057_multiple_clone_groups_sorted_by_hash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(56, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0057_batch_05_cartesian_expansion_0058_html_vendor_combo_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(57, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0058_batch_06_source_and_entrypoints_0010_html_output_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(58, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0059_batch_06_source_and_entrypoints_0024_duplicate_functions_detected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(59, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0060_batch_06_source_and_entrypoints_0041_three_identical_functions_multi_group(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(60, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0061_batch_06_source_and_entrypoints_0042_html_output_with_duplicates(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(61, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0062_batch_06_source_and_entrypoints_0043_plumbing_output_with_duplicates(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(62, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0063_batch_06_source_and_entrypoints_0045_tab_indented_deindent_case(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(63, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0064_batch_06_source_and_entrypoints_0046_crlf_line_endings_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(64, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0065_batch_06_source_and_entrypoints_0047_blank_lines_in_dupl_block(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(65, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0066_batch_06_source_and_entrypoints_0048_read_file_missing_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(66, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0067_batch_06_source_and_entrypoints_0056_repeated_identical_pos_dedup(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(67, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0068_batch_08_fixture_and_state_space_0000_default_run_no_args_finds_dupl_in_two_identical_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(68, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0069_batch_08_fixture_and_state_space_0002_threshold_short_alias_t_equivalent(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(69, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0070_batch_08_fixture_and_state_space_0003_html_output_flag_produces_doctype_header(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(70, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0071_batch_08_fixture_and_state_space_0004_plumbing_output_flag_produces_duplicate_of_lines(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(71, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0072_batch_08_fixture_and_state_space_0008_files_flag_reads_stdin_filenames(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(72, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0073_batch_08_fixture_and_state_space_0009_files_flag_trims_dot_slash_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(73, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0074_batch_08_fixture_and_state_space_0011_vendor_flag_includes_vendor_directory(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(74, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0075_batch_08_fixture_and_state_space_0014_directory_path_arg_recurses_for_go_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(75, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0076_batch_08_fixture_and_state_space_0015_multiple_explicit_paths_combined(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(76, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0077_batch_08_fixture_and_state_space_0018_three_way_duplicate_group_reported_together(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(77, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0078_batch_08_fixture_and_state_space_0021_import_declarations_skipped_in_ast(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(78, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0079_batch_08_fixture_and_state_space_0022_html_output_escapes_special_characters(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(79, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0080_batch_08_fixture_and_state_space_0023_tab_indented_source_deindented_in_html(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(80, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0081_batch_08_fixture_and_state_space_0024_threshold_zero_matches_everything_boundary(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(81, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0082_batch_08_fixture_and_state_space_0025_threshold_negative_value_parsed(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(82, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0083_batch_08_fixture_and_state_space_0026_unknown_flag_produces_usage_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(83, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0084_batch_08_fixture_and_state_space_0028_deeply_nested_directory_structure_crawled(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(84, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0085_batch_08_fixture_and_state_space_0029_non_go_files_ignored_in_directory_crawl(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(85, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0086_batch_08_fixture_and_state_space_0031_vendor_nested_deep_path_included_with_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(86, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0087_batch_08_fixture_and_state_space_0034_three_identical_files_html_grouping_h1_count(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(87, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0088_batch_08_fixture_and_state_space_0035_same_file_multiple_internal_dupl_blocks(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(88, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0089_batch_08_fixture_and_state_space_0036_plumbing_multiple_clone_lines_cyclic_reference(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(89, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0090_batch_08_fixture_and_state_space_0037_crlf_line_endings_in_source_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(90, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0091_batch_08_fixture_and_state_space_0038_empty_go_file_no_declarations(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(91, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0092_batch_08_fixture_and_state_space_0039_struct_and_interface_type_dupl_detected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(92, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0093_batch_08_fixture_and_state_space_0040_switch_statement_dupl_across_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(93, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0094_batch_08_fixture_and_state_space_0041_for_range_loop_dupl_detected(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(94, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0095_batch_09_blackbox_and_boundaries_0045_help_long_flag_form(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(95, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0096_batch_09_blackbox_and_boundaries_0046_threshold_flag_missing_value_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(96, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0097_batch_10_cartesian_expansion_0023_run_help_usage_no_args_bad_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(97, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0098_batch_11_source_and_entrypoints_0001_unknown_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(98, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0099_batch_11_source_and_entrypoints_0006_two_files_exact_duplicate_default_threshold(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(99, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0100_batch_11_source_and_entrypoints_0008_threshold_zero_boundary(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(100, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0101_batch_11_source_and_entrypoints_0009_negative_threshold_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(101, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0102_batch_11_source_and_entrypoints_0023_html_output_header_and_footer(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(102, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0103_batch_11_source_and_entrypoints_0024_html_escapes_special_chars(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(103, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0104_batch_11_source_and_entrypoints_0025_plumbing_output_format(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(104, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0105_batch_11_source_and_entrypoints_0026_text_output_default_footer_count(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(105, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0106_batch_11_source_and_entrypoints_0033_large_identical_functions_clone_detection(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(106, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0107_batch_11_source_and_entrypoints_0034_three_way_clone_group(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(107, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0108_batch_11_source_and_entrypoints_0035_cyclic_pattern_filtered_out(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(108, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0109_batch_11_source_and_entrypoints_0037_html_no_dupls_only_header(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(109, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0110_batch_11_source_and_entrypoints_0038_threshold_boundary_exact_match_length(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(110, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0111_batch_12_docs_and_native_behaviors_0032_duplicate_functions_in_two_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(111, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0112_batch_12_docs_and_native_behaviors_0034_html_output_with_actual_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(112, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0113_batch_12_docs_and_native_behaviors_0035_plumbing_output_with_actual_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(113, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0114_batch_12_docs_and_native_behaviors_0036_three_way_clone_group(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(114, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0115_batch_12_docs_and_native_behaviors_0037_self_referencing_cyclic_pattern(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(115, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0116_batch_12_docs_and_native_behaviors_0038_nested_function_literal_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(116, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0117_batch_13_fixture_and_state_space_0001_single_file_exact_clone_pair(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(117, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0118_batch_13_fixture_and_state_space_0013_html_output_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(118, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0119_batch_13_fixture_and_state_space_0014_plumbing_output_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(119, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0120_batch_13_fixture_and_state_space_0018_files_flag_multiple_lines(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(120, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0121_batch_13_fixture_and_state_space_0021_multiple_path_args(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(121, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0122_batch_13_fixture_and_state_space_0023_three_way_clone_group(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(122, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0123_batch_13_fixture_and_state_space_0029_large_file_many_clones(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(123, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0124_batch_13_fixture_and_state_space_0030_clone_html_fragment_whitespace_indent(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(124, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0125_batch_13_fixture_and_state_space_0037_threshold_zero_boundary(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(125, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0126_batch_13_fixture_and_state_space_0038_threshold_negative_value(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(126, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0127_batch_13_fixture_and_state_space_0043_plumbing_multi_file_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(127, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0128_batch_13_fixture_and_state_space_0044_sort_group_keys_multiple_clone_groups(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(128, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0129_batch_13_fixture_and_state_space_0046_cyclic_pattern_excluded_from_clones(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(129, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0130_batch_13_fixture_and_state_space_0052_unknown_flag_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(130, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0131_batch_13_fixture_and_state_space_0054_deeply_nested_go_file_structure(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(131, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0132_batch_13_fixture_and_state_space_0055_threshold_flag_full_name_high(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(132, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0133_batch_14_blackbox_and_boundaries_0008_html_output_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(133, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0134_batch_14_blackbox_and_boundaries_0009_plumbing_output_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(134, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0135_batch_14_blackbox_and_boundaries_0010_text_default_output_mode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(135, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0136_batch_14_blackbox_and_boundaries_0012_vendor_flag_included(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(136, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0137_batch_14_blackbox_and_boundaries_0017_files_flag_reads_stdin_filenames(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(137, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0138_batch_14_blackbox_and_boundaries_0018_files_flag_trims_dot_slash_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(138, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0139_batch_14_blackbox_and_boundaries_0024_identical_files_full_duplicate(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(139, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0140_batch_14_blackbox_and_boundaries_0025_three_way_duplicate_group(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(140, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0141_batch_14_blackbox_and_boundaries_0026_self_referencing_dup_in_same_file_excluded(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(141, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0142_batch_14_blackbox_and_boundaries_0027_html_output_with_tabs_and_unicode(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(142, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0143_batch_14_blackbox_and_boundaries_0028_html_escapes_special_chars(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(143, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0144_batch_14_blackbox_and_boundaries_0029_plumbing_cyclic_wraparound_reference(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(144, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0145_batch_14_blackbox_and_boundaries_0030_crlf_line_endings_deindent(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(145, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0146_batch_14_blackbox_and_boundaries_0032_multiple_paths_args(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(146, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0147_batch_14_blackbox_and_boundaries_0035_threshold_non_integer_value_error(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(147, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0148_batch_14_blackbox_and_boundaries_0038_deeply_nested_if_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(148, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0149_batch_14_blackbox_and_boundaries_0039_low_threshold_finds_small_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(149, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0150_batch_14_blackbox_and_boundaries_0040_go_files_with_vendor_substring_not_in_vendor_dir(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(150, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0151_batch_14_blackbox_and_boundaries_0041_clone_across_two_directories(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(151, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0152_batch_14_blackbox_and_boundaries_0043_go_file_with_multiple_funcdecls_owns_count(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(152, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0153_batch_14_blackbox_and_boundaries_0050_large_repeated_boilerplate_clone_detection(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(153, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0154_batch_14_blackbox_and_boundaries_0051_switch_stmt_clone_detection(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(154, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0155_batch_14_blackbox_and_boundaries_0052_func_lit_closure_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(155, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0156_batch_14_blackbox_and_boundaries_0053_map_and_chan_type_nodes(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(156, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0157_batch_14_blackbox_and_boundaries_0054_select_stmt_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(157, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0158_batch_14_blackbox_and_boundaries_0055_goroutine_and_defer_stmt_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(158, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0159_batch_14_blackbox_and_boundaries_0056_type_switch_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(159, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0160_batch_14_blackbox_and_boundaries_0057_struct_and_interface_type_decl_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(160, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0161_batch_14_blackbox_and_boundaries_0058_label_and_branch_stmt_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(161, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0162_batch_14_blackbox_and_boundaries_0059_range_stmt_over_slice_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(162, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0163_batch_14_blackbox_and_boundaries_0060_multiple_clone_groups_sorted_by_hash(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(163, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0164_batch_17_docs_and_native_behaviors_0028_duplicate_functions_same_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(164, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0165_batch_17_docs_and_native_behaviors_0043_clone_across_two_separate_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(165, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0166_batch_17_docs_and_native_behaviors_0044_cyclic_pattern_repetition_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(166, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0167_batch_17_docs_and_native_behaviors_0045_nested_func_lit_clone(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(167, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0168_batch_17_docs_and_native_behaviors_0046_switch_stmt_type_switch_variety(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(168, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0169_batch_17_docs_and_native_behaviors_0060_large_repeated_boilerplate_clone_html(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(169, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0170_batch_20_cartesian_expansion_0000_files_flag_reads_stdin_list(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(170, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0171_batch_20_cartesian_expansion_0001_files_flag_trims_dot_slash_prefix(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(171, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0172_batch_20_cartesian_expansion_0002_stdin_files_list_multiple_lines(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(172, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0173_batch_20_cartesian_expansion_0006_large_repeated_boilerplate_text_from_readme_docker_example(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(173, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)
