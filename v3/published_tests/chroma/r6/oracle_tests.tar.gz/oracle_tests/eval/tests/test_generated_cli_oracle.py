"""Generated black-box CLI oracle tests."""

from __future__ import annotations

import contextlib
import base64
import http.server
import json
import os
import re
import signal
import subprocess
import threading
import time
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[2]
EVAL_DIR = Path(__file__).resolve().parents[1]
MANIFEST_PATH = EVAL_DIR / "generated_cli_manifest.json"
if not MANIFEST_PATH.exists():
    MANIFEST_PATH = EVAL_DIR / "generated_yj_manifest.json"
MANIFEST = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
FIXTURE_DIR = EVAL_DIR / "fixtures" / MANIFEST.get("fixture_subdir", "generated_cli")
CASES = MANIFEST["cases"]


@contextlib.contextmanager
def _case_runtime(case: dict, tmp_path: Path):
    for relative, content in case.get("files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    for relative, content in case.get("executable_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe executable fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        target.chmod(0o755)
    for relative, content in case.get("binary_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe binary fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(base64.b64decode(content, validate=True))
    for relative, spec in case.get("repeat_files", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents:
            raise AssertionError(f"unsafe repeated fixture path: {relative}")
        target.parent.mkdir(parents=True, exist_ok=True)
        segments = spec.get("segments")
        content = (
            "".join(segment.get("row", "") * int(segment.get("count", 0)) for segment in segments)
            if isinstance(segments, list)
            else spec.get("prefix", "") + spec.get("row", "") * int(spec.get("count", 0)) + spec.get("suffix", "")
        )
        encoding = str(spec.get("encoding") or "utf-8").lower()
        if encoding in {"latin-1", "latin1"}:
            target.write_bytes(content.encode("latin-1"))
        else:
            target.write_text(content, encoding="utf-8")
    git_fixture = case.get("git") or None
    if git_fixture and git_fixture.get("init") is True:
        git_env = {
            **os.environ,
            "GIT_AUTHOR_NAME": "ProgramBench",
            "GIT_AUTHOR_EMAIL": "programbench@example.invalid",
            "GIT_COMMITTER_NAME": "ProgramBench",
            "GIT_COMMITTER_EMAIL": "programbench@example.invalid",
            "GIT_AUTHOR_DATE": "2000-01-01T00:00:00Z",
            "GIT_COMMITTER_DATE": "2000-01-01T00:00:00Z",
        }
        subprocess.run(["git", "init", "-q", "-b", git_fixture.get("branch", "main")], cwd=tmp_path, env=git_env, check=True)
        if git_fixture.get("commit_all") is not False:
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
            subprocess.run(["git", "commit", "-q", "--allow-empty", "-m", "initial"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("staged_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
        if git_fixture.get("staged_files"):
            subprocess.run(["git", "add", "-A"], cwd=tmp_path, env=git_env, check=True)
        for relative, content in git_fixture.get("untracked_files", {}).items():
            target = (tmp_path / relative).resolve()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    for relative, mode in case.get("file_modes", {}).items():
        target = (tmp_path / relative).resolve()
        if tmp_path.resolve() not in target.parents or not target.exists():
            raise AssertionError(f"invalid file mode fixture path: {relative}")
        target.chmod(int(mode) & 0o777)
    response = case.get("http") or None
    server = None
    thread = None
    url = ""
    if response:
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path != response.get("path", "/"):
                    self.send_error(404)
                    return
                body = response.get("body", "").encode("utf-8")
                self.send_response_only(response.get("status", 200))
                for key, value in response.get("headers", {}).items():
                    self.send_header(key, value)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(body)

            do_POST = do_GET
            do_PUT = do_GET
            do_PATCH = do_GET
            do_DELETE = do_GET
            do_OPTIONS = do_GET
            do_HEAD = do_GET

            def log_message(self, format, *args):
                return

            def date_time_string(self, timestamp=None):
                return "Thu, 01 Jan 1970 00:00:00 GMT"

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_port}{response.get('path', '/')}"
    try:
        yield url
    finally:
        if server:
            server.shutdown()
            server.server_close()
        if thread:
            thread.join(timeout=2)


def _case_timeout(case: dict) -> float:
    timeout = float(case.get("timeout", 5))
    cap = os.environ.get("PROGRAMBENCH_CASE_TIMEOUT_CAP", "").strip()
    if cap:
        timeout = min(timeout, max(0.1, float(cap)))
    return timeout


def _execute_case(index: int, tmp_path: Path) -> tuple[dict, Path, int, bytes, bytes, bytes, bytes]:
    case = CASES[index]
    executable = WORKSPACE / "executable"
    if not executable.exists():
        raise AssertionError(f"missing executable at {executable}")

    stdin_template = (FIXTURE_DIR / case["stdin_file"]).read_bytes()
    expected_stdout = (FIXTURE_DIR / case["stdout_file"]).read_bytes()
    expected_stderr = (FIXTURE_DIR / case["stderr_file"]).read_bytes()
    env = os.environ.copy()
    env["TZ"] = "UTC"
    with _case_runtime(case, tmp_path) as http_url:
        if case.get("isolate_home_tmp") is True:
            isolated_home = tmp_path / ".case-home"
            isolated_tmp = tmp_path / ".case-tmp"
            isolated_home.mkdir(exist_ok=True)
            isolated_tmp.mkdir(exist_ok=True)
            env.update({"HOME": str(isolated_home), "TMPDIR": str(isolated_tmp)})
        env.update({key: value.replace("{http_url}", http_url) for key, value in case.get("env", {}).items()})
        argv0 = case.get("argv0", "/workspace/executable").replace("{http_url}", http_url)
        args = [item.replace("{http_url}", http_url) for item in case["args"]]
        stdin = stdin_template.replace(b"{http_url}", http_url.encode("utf-8"))
        if case.get("terminal"):
            returncode, stdout, stderr = _run_terminal(
                executable=executable,
                argv0=argv0,
                args=args,
                stdin=stdin,
                cwd=tmp_path,
                env=env,
                timeout=_case_timeout(case),
                terminal=case["terminal"],
            )
        else:
            stdin_file = None
            if case.get("stdin_regular_file") is True:
                stdin_path = tmp_path / ".programbench-stdin"
                stdin_path.write_bytes(stdin)
                stdin_file = stdin_path.open("rb")
            proc = subprocess.Popen(
                [argv0, *args],
                executable=str(executable),
                stdin=stdin_file if stdin_file is not None else subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=tmp_path,
                env=env,
                start_new_session=os.name != "nt",
            )
            try:
                stdout, stderr = proc.communicate(
                    input=None if stdin_file is not None else stdin,
                    timeout=_case_timeout(case),
                )
                if stdin_file is not None:
                    stdin_file.close()
            except subprocess.TimeoutExpired:
                if stdin_file is not None:
                    stdin_file.close()
                if os.name != "nt":
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(proc.pid, signal.SIGKILL)
                else:
                    proc.kill()
                proc.communicate()
                raise
            returncode = proc.returncode
        if http_url:
            encoded_url = http_url.encode("utf-8")
            encoded_host = http_url.split("://", 1)[-1].split("/", 1)[0].encode("utf-8")
            stdout = stdout.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")
            stderr = stderr.replace(encoded_url, b"{http_url}").replace(encoded_host, b"{http_host}")
        encoded_workdir = str(tmp_path).encode("utf-8")
        stdout = stdout.replace(encoded_workdir, b"{workdir}")
        stderr = stderr.replace(encoded_workdir, b"{workdir}")

    return case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr


def _run_terminal(*, executable: Path, argv0: str, args: list[str], stdin: bytes, cwd: Path,
                  env: dict[str, str], timeout: int, terminal: dict) -> tuple[int, bytes, bytes]:
    if os.name == "nt":
        raise RuntimeError("terminal cases require a Unix pseudo-terminal")
    import fcntl
    import pty
    import select
    import struct
    import termios

    kind = str(terminal.get("kind") or "generic")
    if kind not in {"generic", "iterm2", "kitty", "sixel"}:
        raise ValueError("terminal.kind must be generic, iterm2, kitty, or sixel")
    rows = max(2, min(200, int(terminal.get("rows", 24))))
    cols = max(2, min(400, int(terminal.get("cols", 80))))
    cell_width = max(1, min(100, int(terminal.get("cell_width", 10))))
    cell_height = max(1, min(100, int(terminal.get("cell_height", 20))))
    max_output = max(1024, min(16 * 1024 * 1024, int(terminal.get("max_output_bytes", 4 * 1024 * 1024))))
    stdin_delay = max(0.0, min(5.0, float(terminal.get("stdin_delay_seconds", 0))))
    stdin_mode = "pipe" if terminal.get("stdin_mode") == "pipe" else "pty"
    run_env = dict(env)
    run_env.update({
        "TERM_PROGRAM": "iTerm.app" if kind == "iterm2" else "ProgramBench",
        "TERM": str(terminal.get("term") or "xterm-256color"),
    })
    master, slave = pty.openpty()
    attrs = termios.tcgetattr(slave)
    attrs[3] &= ~termios.ECHO
    termios.tcsetattr(slave, termios.TCSANOW, attrs)
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    proc = subprocess.Popen(
        [argv0, *args], executable=str(executable),
        stdin=subprocess.PIPE if stdin_mode == "pipe" else slave, stdout=slave, stderr=slave,
        cwd=cwd, env=run_env, start_new_session=True, close_fds=True,
    )
    os.close(slave)
    def feed_stdin() -> None:
        if stdin_delay:
            time.sleep(stdin_delay)
        with contextlib.suppress(BrokenPipeError, OSError):
            if stdin_mode == "pipe":
                if proc.stdin is not None:
                    if stdin:
                        proc.stdin.write(stdin)
                    for event in terminal.get("input_events") or []:
                        delay = max(0.0, min(5.0, float(event.get("after_seconds", 0))))
                        if delay:
                            time.sleep(delay)
                        proc.stdin.write(str(event.get("data") or "").encode("utf-8"))
                    proc.stdin.close()
            else:
                if stdin:
                    os.write(master, stdin)
                for event in terminal.get("input_events") or []:
                    delay = max(0.0, min(5.0, float(event.get("after_seconds", 0))))
                    if delay:
                        time.sleep(delay)
                    os.write(master, str(event.get("data") or "").encode("utf-8"))
                if terminal.get("send_eof") is True:
                    os.write(master, b"\x04")
    feeder = threading.Thread(target=feed_stdin, daemon=True)
    feeder.start()
    output = bytearray()
    responses = {b"\x1b[14t": f"\x1b[4;{rows * cell_height};{cols * cell_width}t".encode("ascii")}
    if kind == "iterm2":
        responses[b"\x1b]1337;ReportCellSize\x07"] = f"\x1b]1337;ReportCellSize={cell_height};{cell_width}\x1b\\".encode("ascii")
    if kind == "kitty":
        responses[b"\x1b_Gi=1,a=q,t=d,f=24\x1b\\"] = b"\x1b_Gi=1;OK\x1b\\"
    if kind == "sixel":
        responses[b"\x1b[c"] = b"\x1b[?62;4;c"
    responded: set[bytes] = set()
    deadline = time.monotonic() + timeout
    try:
        while proc.poll() is None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=5)
                raise subprocess.TimeoutExpired([argv0, *args], timeout, output=bytes(output))
            ready, _, _ = select.select([master], [], [], min(0.1, remaining))
            if not ready:
                continue
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            output.extend(chunk)
            if len(output) > max_output:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(proc.pid, signal.SIGKILL)
                raise RuntimeError("terminal case exceeded max_output_bytes")
            for query, response in responses.items():
                if query not in responded and query in output:
                    os.write(master, response)
                    responded.add(query)
        proc.wait(timeout=5)
        while True:
            ready, _, _ = select.select([master], [], [], 0.02)
            if not ready:
                break
            try:
                chunk = os.read(master, 65536)
            except OSError:
                break
            if not chunk:
                break
            output.extend(chunk)
    finally:
        feeder.join(timeout=6)
        os.close(master)
    return proc.returncode, bytes(output), b""


GO_LOG_PREFIX_RE = re.compile(
    rb"(?m)^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}(?:\.\d+)?(?: [^ \r\n]+\.go:\d+:)? "
)
BENCH_DURATION_RE = re.compile(
    rb"(?m)^(\s*(?:Total|Slowest|Fastest|Average):\s*)[0-9.]+(\s+secs\.)$"
)
BENCH_RATE_RE = re.compile(rb"(?m)^(\s*Requests/sec:\s*)[0-9.]+$")
BENCH_HISTOGRAM_RE = re.compile(rb"(?m)^(\s*)[0-9.]+(\s+\[\d+\]\s*\|.*)$")
BENCH_LATENCY_RE = re.compile(rb"(?m)^(\s*\d+% in\s*)[0-9.]+(\s+secs\.)$")
SEVENZIP_BENCH_NUMBER_RE = re.compile(rb"(?<![A-Za-z])[+-]?\d+(?:\.\d+)?(?:[A-Za-z/%]+)?")


EPOCH_NUMBER_RE = re.compile(rb"(?<!\d)[1-3]\d{9}(?!\d)")
ANSI_ESCAPE_RE = re.compile(rb"\x1b(?:\[[0-?]*[ -/]*[@-~]|.)", re.DOTALL)
NINJA_GRAPHVIZ_ID_RE = re.compile(rb"\b0x[0-9a-fA-F]+\b")
NINJA_COMPDB_DIRECTORY_RE = re.compile(rb'("directory"\s*:\s*")[^"]*(")')
NINJA_STATS_NUMBER_RE = re.compile(rb"(?<![A-Za-z])\d+(?:\.\d+)?")


def _normalize_ninja_graphviz_ids(value: bytes) -> bytes:
    return NINJA_GRAPHVIZ_ID_RE.sub(b"0xNODE", value)


def _normalize_ninja_compdb_directory(value: bytes) -> bytes:
    return NINJA_COMPDB_DIRECTORY_RE.sub(rb'\g<1><WORKDIR>\g<2>', value)


def _normalize_ninja_stats(value: bytes) -> bytes:
    return NINJA_STATS_NUMBER_RE.sub(b"<N>", value)


def _normalize_terminal_control_tail(value: bytes) -> bytes:
    cursor = 0
    last_visible_end = 0
    for match in ANSI_ESCAPE_RE.finditer(value):
        chunk = value[cursor:match.start()]
        if chunk.strip():
            last_visible_end = match.start()
        cursor = match.end()
    if value[cursor:].strip():
        last_visible_end = len(value)
    if not last_visible_end or last_visible_end == len(value):
        return value
    return value[:last_visible_end] + b"\n<TERMINAL_CONTROL_TAIL>\n"


def _normalize_benchmark_output(value: bytes) -> bytes:
    value = BENCH_DURATION_RE.sub(rb"\g<1>0.0000\g<2>", value)
    value = BENCH_RATE_RE.sub(rb"\g<1>0.0000", value)
    value = BENCH_HISTOGRAM_RE.sub(rb"\g<1>0.000\g<2>", value)
    value = BENCH_LATENCY_RE.sub(rb"\g<1>0.0000\g<2>", value)
    if b"Compressing  |" not in value:
        return value
    lines = value.splitlines(keepends=True)
    table_index = next(i for i, line in enumerate(lines) if b"Compressing  |" in line)
    system_index = next(
        (
            i
            for i, line in enumerate(lines[:table_index])
            if line.strip().startswith((b"Compiler:", b"Linux :", b"PageSize:"))
        ),
        table_index,
    )
    lines = lines[:system_index] + [b"<SYSTEM>\n", b"\n"] + lines[table_index:]
    normalized = []
    in_table = False
    for line in lines:
        if b"Compressing  |" in line:
            in_table = True
        if in_table and any(48 <= byte <= 57 for byte in line):
            line = SEVENZIP_BENCH_NUMBER_RE.sub(b"<N>", line)
            line = b" ".join(line.split()) + b"\n"
        normalized.append(line)
    return b"".join(normalized)


TUI_WPM_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=WPM\b)")
TUI_ACC_METRIC_RE = re.compile(rb"(\b(?:avg\.|last)\s*)-?\d+(?=% Acc\b)")


def _normalize_tui_metrics(value: bytes) -> bytes:
    value = TUI_WPM_METRIC_RE.sub(rb"\g<1><WPM>", value)
    return TUI_ACC_METRIC_RE.sub(rb"\g<1><ACC>", value)


def _assert_stdout(case: dict, stdout: bytes, expected_stdout: bytes) -> None:
    if case.get("stdout_mode") == "lines_unordered":
        assert sorted(stdout.splitlines()) == sorted(expected_stdout.splitlines())
    else:
        assert stdout == expected_stdout


def _assert_observed_files(case: dict, tmp_path: Path) -> None:
    root = tmp_path.resolve()
    for relative, expected in case.get("observed_files", {}).items():
        target = tmp_path / relative
        exists = target.exists() or target.is_symlink()
        assert exists is bool(expected.get("exists")), f"post-run existence mismatch: {relative}"
        if not exists:
            continue
        resolved = target.resolve()
        assert resolved == root or root in resolved.parents, f"post-run path escaped workspace: {relative}"
        kind = expected.get("kind")
        if kind == "directory":
            assert target.is_dir(), f"expected post-run directory: {relative}"
        elif kind == "file":
            assert target.is_file(), f"expected post-run file: {relative}"
            expected_bytes = base64.b64decode(expected.get("content_base64", ""), validate=True)
            assert target.read_bytes() == expected_bytes, f"post-run bytes mismatch: {relative}"


def _normalize_terminal_final_screen(value: bytes, *, rows: int, cols: int) -> bytes:
    """Reconstruct the final visible ANSI terminal screen for exact comparison."""

    rows = max(2, min(200, int(rows)))
    cols = max(2, min(400, int(cols)))
    screen = [[" "] * cols for _ in range(rows)]
    row = col = 0
    saved = (0, 0)
    last_screen: list[list[str]] | None = None
    text = value.decode("utf-8", "replace")

    def clear_all() -> None:
        nonlocal screen
        screen = [[" "] * cols for _ in range(rows)]

    def snapshot() -> None:
        nonlocal last_screen
        last_screen = [line[:] for line in screen]

    index = 0
    while index < len(text):
        char = text[index]
        if char == "\x1b":
            if index + 1 < len(text) and text[index + 1] == "[":
                match = re.match(r"\x1b\[([0-?]*)([ -/]*)([@-~])", text[index:])
                if match:
                    params, _, command = match.groups()
                    index += len(match.group(0))
                    private = params.startswith("?")
                    raw_params = params[1:] if private else params
                    numbers = [int(item) if item else 0 for item in raw_params.split(";")] if raw_params else []
                    first = numbers[0] if numbers else 0
                    if private and first == 1049 and command == "h":
                        clear_all()
                        row = col = 0
                    elif private and first == 1049 and command == "l":
                        snapshot()
                    elif command in {"H", "f"}:
                        row = max(0, min(rows - 1, (numbers[0] if numbers else 1) - 1))
                        col = max(0, min(cols - 1, (numbers[1] if len(numbers) > 1 else 1) - 1))
                    elif command == "A":
                        row = max(0, row - (first or 1))
                    elif command == "B":
                        row = min(rows - 1, row + (first or 1))
                    elif command == "C":
                        col = min(cols - 1, col + (first or 1))
                    elif command == "D":
                        col = max(0, col - (first or 1))
                    elif command == "E":
                        row, col = min(rows - 1, row + (first or 1)), 0
                    elif command == "F":
                        row, col = max(0, row - (first or 1)), 0
                    elif command in {"G", "`"}:
                        col = max(0, min(cols - 1, (first or 1) - 1))
                    elif command == "d":
                        row = max(0, min(rows - 1, (first or 1) - 1))
                    elif command == "J":
                        if first in {2, 3}:
                            clear_all()
                        elif first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                            for target in range(row + 1, rows):
                                screen[target] = [" "] * cols
                        elif first == 1:
                            for target in range(row):
                                screen[target] = [" "] * cols
                            screen[row][: col + 1] = [" "] * (col + 1)
                    elif command == "K":
                        if first == 0:
                            screen[row][col:] = [" "] * (cols - col)
                        elif first == 1:
                            screen[row][: col + 1] = [" "] * (col + 1)
                        elif first == 2:
                            screen[row] = [" "] * cols
                    elif command == "s":
                        saved = (row, col)
                    elif command == "u":
                        row, col = saved
                    continue
            if index + 1 < len(text) and text[index + 1] in {"7", "8"}:
                if text[index + 1] == "7":
                    saved = (row, col)
                else:
                    row, col = saved
                index += 2
                continue
            if index + 1 < len(text) and text[index + 1] == "]":
                end_bel = text.find("\x07", index + 2)
                end_st = text.find("\x1b\\", index + 2)
                endings = [item for item in (end_bel, end_st) if item >= 0]
                index = (min(endings) + (2 if min(endings) == end_st else 1)) if endings else len(text)
                continue
            index += 2
            continue
        if char == "\r":
            col = 0
        elif char == "\n":
            row = min(rows - 1, row + 1)
        elif char == "\b":
            col = max(0, col - 1)
        elif char >= " " and char != "\x7f":
            screen[row][col] = char
            col += 1
            if col >= cols:
                col = 0
                row = min(rows - 1, row + 1)
        index += 1

    selected = last_screen or screen
    lines = ["".join(line).rstrip() for line in selected]
    while lines and not lines[-1]:
        lines.pop()
    return ("<TERMINAL_FINAL_SCREEN>\n" + "\n".join(lines) + "\n").encode("utf-8")


def test_0000_batch_01_reachability_and_anchor_repair_0001_lexer_go_fail_file_input(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(0, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0001_batch_01_reachability_and_anchor_repair_0002_check_flag_go_stdin(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(1, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0002_batch_01_reachability_and_anchor_repair_0003_check_flag_go_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(2, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0003_batch_01_reachability_and_anchor_repair_0004_check_flag_python_error_file(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(3, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0004_batch_01_reachability_and_anchor_repair_0005_unbuffered_flag_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(4, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0005_batch_01_reachability_and_anchor_repair_0006_trace_flag_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(5, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0006_batch_01_reachability_and_anchor_repair_0007_html_highlight_single_line(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(6, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0007_batch_01_reachability_and_anchor_repair_0008_html_highlight_range(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(7, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0008_batch_01_reachability_and_anchor_repair_0009_html_highlight_multi_ranges(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(8, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0009_batch_01_reachability_and_anchor_repair_0010_html_highlight_style_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(9, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0010_batch_01_reachability_and_anchor_repair_0011_html_lines_style_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(10, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0011_batch_01_reachability_and_anchor_repair_0012_lessfilter_argv0_fallback(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(11, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0012_batch_01_reachability_and_anchor_repair_0014_xml_lexer_missing_path_expected_fail(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(12, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0013_batch_01_reachability_and_anchor_repair_0016_list_flag_repeat_anchor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(13, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0014_batch_01_reachability_and_anchor_repair_0017_version_flag_repeat_anchor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(14, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0015_batch_01_reachability_and_anchor_repair_0018_style_monokai_go_success_anchor(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(15, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0016_batch_01_reachability_and_anchor_repair_0019_style_case_insensitive_lower(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(16, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0017_batch_01_reachability_and_anchor_repair_0020_style_dracula_lower_variant(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(17, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0018_batch_01_reachability_and_anchor_repair_0021_html_styles_dump_swapoff_default(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(18, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0019_batch_01_reachability_and_anchor_repair_0022_html_all_styles_flag_monokai(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(19, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0020_batch_01_reachability_and_anchor_repair_0023_html_full_output_dracula_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(20, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0021_batch_01_reachability_and_anchor_repair_0024_terminal256_python_dracula(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(21, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0022_batch_01_reachability_and_anchor_repair_0025_terminal_vim_style_python(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(22, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0023_batch_01_reachability_and_anchor_repair_0026_quick_example_python_html_dracula(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(23, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0024_batch_01_reachability_and_anchor_repair_0027_highlight_go_file_html_monokai(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(24, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0025_batch_01_reachability_and_anchor_repair_0028_highlight_python_file_terminal256_github(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(25, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0026_batch_01_reachability_and_anchor_repair_0029_custom_xml_style_file_python(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(26, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0027_batch_01_reachability_and_anchor_repair_0031_html_prefix_custom_class_dracula(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(27, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0028_batch_01_reachability_and_anchor_repair_0032_html_inline_styles_github(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(28, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0029_batch_01_reachability_and_anchor_repair_0033_html_lines_table_monokai(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(29, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0030_batch_01_reachability_and_anchor_repair_0034_html_base_line_number_custom(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(30, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0031_batch_01_reachability_and_anchor_repair_0035_html_prevent_surrounding_pre(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(31, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0032_batch_01_reachability_and_anchor_repair_0036_html_linkable_lines_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(32, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0033_batch_01_reachability_and_anchor_repair_0037_html_tab_width_custom(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(33, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0034_batch_01_reachability_and_anchor_repair_0038_formatter_json_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(34, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0035_batch_01_reachability_and_anchor_repair_0039_json_convenience_flag_python(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(35, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0036_batch_01_reachability_and_anchor_repair_0040_svg_convenience_flag_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(36, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0037_batch_01_reachability_and_anchor_repair_0041_formatter_tokens_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(37, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0038_batch_01_reachability_and_anchor_repair_0042_formatter_noop_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(38, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0039_batch_01_reachability_and_anchor_repair_0043_autodetect_lexer_from_filename_py(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(39, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0040_batch_01_reachability_and_anchor_repair_0044_autodetect_lexer_stdin_content_analyse(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(40, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0041_batch_01_reachability_and_anchor_repair_0045_autodetect_lexer_analyse_only_stdin(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(41, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0042_batch_01_reachability_and_anchor_repair_0046_multi_file_processing_two_go_files(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(42, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0043_batch_01_reachability_and_anchor_repair_0047_fail_flag_unrecognized_content_exit(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(43, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0044_batch_01_reachability_and_anchor_repair_0048_filename_hint_with_fail_flag(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(44, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0045_batch_01_reachability_and_anchor_repair_0049_large_input_peek_boundary_go(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(45, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0046_batch_01_reachability_and_anchor_repair_0050_html_wrap_long_lines_equivalent_check(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(46, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0047_batch_01_reachability_and_anchor_repair_0051_empty_stdin_default_lexer_lenient(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(47, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0048_batch_01_reachability_and_anchor_repair_0052_stdin_with_filename_hint_go_ext(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(48, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0049_batch_01_reachability_and_anchor_repair_0053_check_flag_clean_file_no_errors(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(49, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)


def test_0050_batch_01_reachability_and_anchor_repair_0054_multiple_highlight_flags_combo(tmp_path: Path) -> None:
    """CATCHES: implementations whose exact exit status, stdout, or stderr differs from the reference behavior."""
    case, executable, returncode, stdout, stderr, expected_stdout, expected_stderr = _execute_case(50, tmp_path)
    assert executable.exists(), f"missing executable at {executable}"
    assert returncode == case["returncode"]
    if case.get("normalize_benchmark_output") is True:
        stdout = _normalize_benchmark_output(stdout)
        stderr = _normalize_benchmark_output(stderr)
    if case.get("normalize_epoch_numbers") is True:
        stdout = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stdout)
        stderr = EPOCH_NUMBER_RE.sub(b"<EPOCH>", stderr)
    if (case.get("terminal") or {}).get("output_mode") == "control_tail_trim":
        stdout = _normalize_terminal_control_tail(stdout)
    if (case.get("terminal") or {}).get("output_mode") == "final_screen":
        terminal = case.get("terminal") or {}
        stdout = _normalize_terminal_final_screen(
            stdout, rows=int(terminal.get("rows", 24)), cols=int(terminal.get("cols", 80))
        )
    if case.get("normalize_tui_metrics") is True:
        stdout = _normalize_tui_metrics(stdout)
    if case.get("normalize_ninja_graphviz_ids") is True:
        stdout = _normalize_ninja_graphviz_ids(stdout)
    if case.get("normalize_ninja_compdb_directory") is True:
        stdout = _normalize_ninja_compdb_directory(stdout)
    if case.get("normalize_ninja_stats") is True:
        stdout = _normalize_ninja_stats(stdout)
    _assert_stdout(case, stdout, expected_stdout)
    if case.get("normalize_go_log_prefix") is True:
        stderr = GO_LOG_PREFIX_RE.sub(b"", stderr)
    assert stderr == expected_stderr
    _assert_observed_files(case, tmp_path)
